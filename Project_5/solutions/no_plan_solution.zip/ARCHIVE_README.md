# No Plan is a plan - submitted Project 5 solution

Source: [Andische22/sixt-hackathon-2026](https://github.com/Andische22/sixt-hackathon-2026/tree/6fe3bf63cccf0b592684be75c6351fe95ce3ddee/Project_5), commit `6fe3bf63cccf0b592684be75c6351fe95ce3ddee`.

This archive contains the reviewed team-authored submission files with their original `Project_5/` layout, plus the source repository's `LICENSE`. The files are preserved byte for byte. `SOURCE_MANIFEST.json` records every included source path and checksum, and lists omitted organizer material or generated files.

Extract this archive into a separate working copy of the challenge repository so that `Project_5/` is at the repository root. Read `Project_5/SUBMISSION.md` and the implementation README files before running anything. Programs were not executed during archiving.

Download the official [Stage 1 release](https://github.com/sixt-hackathon-2026/sixt-hackathon-2026/blob/main/Project_5/releases/problem7_student_start.zip) and [Stage 2 release](https://github.com/sixt-hackathon-2026/sixt-hackathon-2026/blob/main/Project_5/releases/problem7_student_final.zip) separately. Restore the release/example files from the main repository and extract the datasets at the exact paths required by the team's instructions. Install the team's declared dependencies and obtain any model access separately.

The canonical scored files are `Project_5/public_answers.csv` and, when present, `Project_5/final_answers.csv`. Other answer copies, experiments, logs and intermediate outputs retain the meanings stated by their authors. Student answers are not an organizer answer key.

The archive preserves the team's own report and slides, including statements that may have been superseded by the organizer's later provisional results or bonus rulings. Refer to the Project 5 results sheet for those decisions.

The submitted C# executable is not bundled. Its source is in `Project_5/solution python/codex_integer_search.cs`; follow the team README build command or documented Python fallback.
