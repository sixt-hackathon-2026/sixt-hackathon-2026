# Open solution R.Rproj in RStudio, then source this file.
source("codex_data.R") 
source("codex_metrics.R")
source("codex_operations.R")
source("codex_scenarios.R")

answer_format <- function(value,type) {
  if (is.na(value)) return("N/A")
  if (is.logical(value)) return(tolower(as.character(value)))
  if (type=="integer") {
    stopifnot(value==trunc(value))
    return(sprintf("%.0f",value))
  }
  if (type=="number") {
    value <- round(value*100)/100
    return(sprintf("%.2f",if (value==0) 0 else value))
  }
  as.character(value)
}

solve <- function(package="../problem7_student_start",questions="public_leaderboard_questions.csv",
                  output=NULL, aliases=NULL, examples=FALSE) {
  if (examples) questions <- "solved_examples.csv"
  if (!is.null(output) && basename(output)=="public_answers.csv" &&
      questions!="public_leaderboard_questions.csv") stop("Choose a separate output filename.")
  q <- csv(file.path(package,questions))
  tables <- dataset(package,aliases)
  b <- operations(business(tables))
  b$attributed <- attributed_rows(b)
  cached <- new.env(parent=emptyenv())
  scenario <- function(text) {
    m <- match_q("(?:decision )?case ([A-Za-z0-9_]+),",text)
    stopifnot(length(m)==1)
    id <- m[1]
    engine <- if (id %in% tables("hard_opt_cases")$case_id) optimum else replay
    if (!exists(id,cached,inherits=FALSE)) assign(id,engine(tables,id),cached)
    baseline <- get(id,cached,inherits=FALSE)
    if (grepl("change in",text,fixed=TRUE)) (engine(tables,id,TRUE)-baseline)/100 else baseline/100
  }
  number <- num(sub("^\\D+","",q$question_id,perl=TRUE))
  results <- data.frame(question_id=q$question_id,answer=vapply(seq_len(nrow(q)),function(j) {
    text <- q$question[j]
    tryCatch({
      value <- if (number[j]>150) scenario(text)
      else if (number[j]<=100 && !examples) legacy(b,text)
      else tryCatch(operation(b,text),error=function(e) {
        if (conditionMessage(e)!="Unmapped operations question") stop(e)
        legacy(b,text)
      })
      answer_format(value,q$answer_type[j])
    },error=function(e) {
      message(q$question_id[j],": ",conditionMessage(e))
      ""
    })
  },character(1)))
  if (examples) {
    results$expected <- q$answer
    is_numeric <- q$answer_type=="number" & !q$answer %in% c("N/A","")
    results$ok <- results$answer==q$answer
    results$ok[is_numeric] <- abs(suppressWarnings(num(results$answer[is_numeric]))-
                                    num(q$answer[is_numeric]))<=.01+1e-12
  }
  if (!is.null(output)) write.table(results[c("question_id","answer")],output,sep=",",quote=TRUE,
                                    qmethod="double",row.names=FALSE,na="",fileEncoding="UTF-8")
  results
}

if (sys.nframe()==0L) {
  args <- commandArgs(trailingOnly=TRUE)
  if (identical(args,"--examples")) {
    result <- solve(examples=TRUE)
    print(result,row.names=FALSE)
    stopifnot(isTRUE(all(result$ok)))
  } else {
    result <- solve(output="public_answers.csv")
    cat(sum(nzchar(result$answer)),"/",nrow(result),"answered\n")
    if (any(!nzchar(result$answer))) quit(status=1)
  }
}
