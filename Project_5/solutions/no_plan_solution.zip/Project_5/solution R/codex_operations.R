#answering the second part of the questions

operations <- function(b) {
  table <- b$table; fx <- b$fx
  suppliers <- table("suppliers")
  p <- add(table("purchase_order_lines"),suppliers,"supplier_id",
           c("country","supplier_name","is_test_supplier","contract_start","contract_end"))
  p$date <- stamp(p$ordered_at); p$due <- stamp(p$promised_at)
  p <- subset(p,status %in% c("open","closed") & date<=ref & !flag(is_test_supplier) &
                stamp(contract_start)<=date & date<stamp(contract_end))
  p <- add(p,b$p,"product_id",c("family","standard_cost","cost_currency"))
  p$units <- num(p$ordered_units); p$price <- num(p$unit_cost_native)
  p$price_eur <- p$price*fx(p$date,p$currency)
  g <- table("goods_receipts")
  g <- subset(g,status=="posted" & po_line_id %in% p$po_line_id)
  g <- add(g,p,"po_line_id",c("warehouse_region","country","supplier_name","family","price","currency","date","due"))
  g$received <- stamp(g$received_at)
  g <- subset(g,date<=received & received<=ref)
  g$accepted <- num(g$accepted_units); g$rejected <- num(g$rejected_units)
  g$cost <- g$accepted*g$price*fx(g$received,g$currency)
  p$remaining <- pmax(0,p$units-lookup(sum_by(g$accepted,g$po_line_id),p$po_line_id))
  g_on <- subset(g,received<=due)
  p$on_time <- pmin(p$units,lookup(sum_by(g_on$accepted,g_on$po_line_id),p$po_line_id))

  w <- table("warehouse_inventory")
  w$stock_key <- key(w$warehouse_region,w$product_id)
  move <- subset(table("inventory_movements"),status=="posted" & stamp(event_at)<=ref)
  stopifnot(!anyDuplicated(move$movement_id))
  move$stock_key <- key(move$warehouse_region,move$product_id)
  move <- add(move,w,"stock_key","last_stocktake_date")
  move <- subset(move,stamp(event_at)>stamp(last_stocktake_date))
  move$delta <- num(move$units_delta)
  w$end <- num(w$on_hand_units)+lookup(sum_by(move$delta,move$stock_key),w$stock_key)
  policy <- subset(table("stock_policies"),stamp(valid_from)<=ref & ref<stamp(valid_to))
  policy$stock_key <- key(policy$warehouse_region,policy$product_id)
  stopifnot(!anyDuplicated(policy$stock_key),all(w$stock_key %in% policy$stock_key))
  w <- add(w,policy,"stock_key",c("target_units","reorder_point"))
  w <- add(w,b$p,"product_id",c("standard_cost","cost_currency"))
  w$value <- w$end*num(w$standard_cost)*fx(ref,w$cost_currency)
  w$below <- w$end<num(w$reorder_point)
  w$reorder <- ifelse(w$below,pmax(0,num(w$target_units)-w$end),0)

  inspections <- subset(table("return_inspections"),status=="completed" & refund_id %in% b$r$refund_id)
  inspections <- add(inspections,b$r,"refund_id",c("refund_date","refund_reason","category"))
  inspections <- subset(inspections,stamp(refund_date)<=stamp(inspected_at) & stamp(inspected_at)<=ref)
  inspections$recovery <- num(inspections$restockable_units)*num(inspections$recovery_unit_value_eur)
  logs <- subset(table("support_worklogs"),work_status=="approved" & ticket_id %in% b$t$ticket_id)
  logs <- add(logs,b$t,"ticket_id",c("opened_at","issue_type","support_channel","country","account_id","segment"))
  logs <- subset(logs,stamp(opened_at)<=stamp(worked_at) & stamp(worked_at)<=ref)
  logs$minutes <- num(logs$minutes_worked)
  logs$labor <- logs$minutes/60*num(logs$hourly_rate_native)*fx(logs$worked_at,logs$currency)
  versions <- subset(table("account_contract_versions"),stamp(recorded_at)<=ref)
  versions <- versions[order(-seconds(versions$recorded_at),-num(versions$revision),method="radix"),]
  contracts <- subset(versions[!duplicated(versions$contract_id),],status=="active" & account_id %in% b$a$account_id)
  contracts <- add(contracts,b$a,"account_id","segment")
  b$ops <- list(p=p,g=g,w=w,move=move,r=inspections,logs=logs,contracts=contracts)
  b
}

operation <- function(b,q) {
  p <- b$ops$p; g <- b$ops$g; w <- b$ops$w; r <- b$ops$r; logs <- b$ops$logs
  if (length(m <- match_q("For support issue (.+?),",q))) {
    rows <- logs[logs$issue_type==m[1],]
    if (grepl("labor cost",q,fixed=TRUE)) return(sum(rows$labor))
    if (grepl("no eligible worklog",q,fixed=TRUE))
      return(sum(b$t$issue_type==m[1] & !b$t$ticket_id %in% rows$ticket_id))
  }
  if (length(m <- match_q("For refund reason (.+?),",q))) {
    rows <- r[r$refund_reason==m[1],]
    if (grepl("restockable",q,fixed=TRUE)) return(pct(sum(num(rows$restockable_units)),sum(num(rows$units_received))))
    if (grepl("no eligible inspection",q,fixed=TRUE))
      return(sum(b$r$refund_reason==m[1] & !b$r$refund_id %in% rows$refund_id))
  }
  if (length(m <- match_q("For original order-time category (.+?),",q))) {
    recovery <- sum(r$recovery[r$category==m[1]])
    if (grepl("adjusted",q,fixed=TRUE))
      return(pct(sum(b$r$eur[b$r$category==m[1]])-recovery,sum(b$i$gross[b$i$category==m[1]])))
    return(recovery)
  }
  if (length(m <- match_q("(?:For|In) warehouse (.+?),",q))) {
    if (grepl("cost of accepted units",q,fixed=TRUE)) return(sum(g$cost[g$warehouse_region==m[1]]))
    if (grepl("units remain outstanding",q,fixed=TRUE)) return(sum(p$remaining[p$warehouse_region==m[1]]))
    rows <- w[w$warehouse_region==m[1],]
    phrases <- c("total reconciled stock"="end","value of reconciled stock"="value",
                 "strictly below the reorder point"="below","replenishment units"="reorder")
    for (phrase in names(phrases)) if (grepl(phrase,q,fixed=TRUE)) return(sum(rows[[phrases[[phrase]]]]))
    move <- b$ops$move[b$ops$move$warehouse_region==m[1],]
    if (grepl("adjustment",q,fixed=TRUE)) return(sum(move$delta[move$movement_type=="adjustment"]))
    if (grepl("coverage days",q,fixed=TRUE))
      return(div(92*sum(rows$end),-sum(move$delta[move$movement_type=="sale_issue" & period(move$event_at,"Q4")])))
  }
  if (length(m <- match_q("(?:For suppliers|Among eligible suppliers) in (.+?)(?:,| with)",q))) {
    p <- p[p$country==m[1],]; g <- g[g$country==m[1],]
    if (grepl("purchase commitment",q,fixed=TRUE)) return(sum(p$units*p$price_eur))
    if (grepl("accepted on time",q,fixed=TRUE)) {
      due <- p$due<=ref; return(pct(sum(p$on_time[due]),sum(p$units[due])))
    }
    if (grepl("rejected-unit percentage",q,fixed=TRUE)) return(pct(sum(g$rejected),sum(g$accepted+g$rejected)))
    if (grepl("highest rejected/",q,fixed=TRUE))
      return(pick(sum_by(g$rejected,g$supplier_name)/sum_by(g$accepted+g$rejected,g$supplier_name)))
    if (grepl("shortfall",q,fixed=TRUE)) return(sum((p$remaining*p$price_eur)[p$due<=ref]))
    if (grepl("count|how many",q)) return(nrow(g))
  }
  if (length(m <- match_q("For product family (.+?),",q))) {
    if (m[1]!="All families") { p <- p[p$family==m[1],]; g <- g[g$family==m[1],] }
    if (grepl("purchase price variance",q,fixed=TRUE))
      return(sum(p$units*(p$price_eur-num(p$standard_cost)*b$fx(p$date,p$cost_currency))))
    if (grepl("supplier",q,fixed=TRUE)) return(pick(sum_by(g$accepted,g$supplier_name)))
  }
  if (length(m <- match_q("For support channel (.+?),",q)))
    return(sum(logs$minutes[logs$support_channel==m[1] & flag(logs$is_billable)])/60)
  if (length(m <- match_q("For (?:customers in )?(.+?), which (?:support )?issue type",q))) {
    t <- b$t[b$t$country==m[1],]
    labor <- lookup(sum_by(logs$labor,logs$ticket_id),t$ticket_id)
    return(pick(tapply(labor,t$issue_type,mean)))
  }
  if (length(m <- match_q("(?:For|Among) accounts in the (.+?) segment,",q))) {
    contracts <- b$ops$contracts[b$ops$contracts$segment==m[1],]
    t <- b$t[b$t$segment==m[1],]
    logs <- logs[logs$segment==m[1],]
    active <- function(date) which(stamp(contracts$valid_from)<=date & date<stamp(contracts$valid_to))
    match_ticket <- vapply(seq_len(nrow(t)),function(j) {
      idx <- active(t$date[j])
      match(t$account_id[j],contracts$account_id[idx]) |> (\(k) if (is.na(k)) NA_integer_ else idx[k])()
    },integer(1))
    credits <- sum(num(contracts$service_credit_eur[match_ticket[t$breach & !is.na(match_ticket)]]))
    if (grepl("coverage|percentage",q)) return(pct(sum(!is.na(match_ticket)),nrow(t)))
    if (grepl("adjusted margin",q,fixed=TRUE)) return(sum(b$i$margin[b$i$segment==m[1]])-sum(logs$labor)-credits)
    if (grepl("total service cost",q,fixed=TRUE)) return(sum(logs$labor)+credits)
    if (grepl("service credit",q,fixed=TRUE)) return(credits)
    if (grepl("run-rate",q,fixed=TRUE)) return(sum(num(contracts$quarterly_fee_eur[active(ref)])))
    if (grepl("overage",q,fixed=TRUE)) {
      idx <- active("2024-10-01 00:00:00")
      q4 <- logs[period(logs$worked_at,"Q4"),]
      return(sum(pmax(0,lookup(sum_by(q4$minutes,q4$account_id),contracts$account_id[idx])-
                        num(contracts$included_support_minutes[idx]))))
    }
  }
  stop("Unmapped operations question")
}
