#Data handling according to the ruleset

ref <- "2025-01-01 00:00:00"
csv <- function(path) {
  lines <- readLines(path,encoding="UTF-8",warn=FALSE)
  if (length(lines)) lines[1] <- sub("^\ufeff","",lines[1])
  rows <- read.csv(text=lines,colClasses="character",na.strings=NULL,check.names=FALSE,encoding="UTF-8")
  if (anyDuplicated(names(rows))) stop("Duplicate CSV column names: ",path)
  rows
}
num <- as.numeric
flag <- function(x) tolower(x) %in% c("1","true","yes")
stamp <- function(x) {
  x <- gsub("T"," ",x,fixed=TRUE)
  ifelse(nchar(x)==10L,paste(x,"00:00:00"),ifelse(nchar(x)==16L,paste0(x,":00"),x))
}
seconds <- function(x) as.numeric(as.POSIXct(stamp(x),format="%Y-%m-%d %H:%M:%OS",tz="UTC"))
window <- function(start,end,days) {
  elapsed <- seconds(end)-seconds(start)
  !is.na(elapsed) & elapsed>=0 & elapsed<=86400*days
}
key <- function(...) paste(..., sep="\034")
pct <- function(a,b) if (b==0) NA_real_ else 100*a/b
div <- function(a,b) if (b==0) NA_real_ else a/b
sum_by <- function(values, keys) tapply(values,keys,sum)
pick <- function(scores, n=1L) {
  labels <- names(scores)[order(-scores,names(scores),method="radix",na.last=NA)]
  if (!length(labels)) NA_character_ else paste(head(labels,n),collapse=";")
}
lookup <- function(values, names, default=0) {
  found <- unname(values[names])
  found[is.na(found)] <- default
  found
}
period <- function(date,p) {
  if (startsWith(p,"Q")) {
    first <- (num(substr(p,2,2))-1)*3+1
    date>=sprintf("2024-%02d-01",first) &
      date < if (first==10) "2025-01-01" else sprintf("2024-%02d-01",first+3)
  } else startsWith(date,p)
}
match_q <- function(pattern,q) {
  m <- regmatches(q,regexec(pattern,q,perl=TRUE))[[1]]
  if (length(m)) m[-1] else NULL
}
add <- function(x,y,by,columns) {
  i <- match(x[[by]],y[[by]])
  for (column in columns) x[[column]] <- y[[column]][i]
  x
}
dataset <- function(package,aliases=NULL) {
  # Map final-stage headers before any joins or metric calculations.
  if (is.null(aliases) && file.exists(file.path(package,"final_questions.csv"))) {
    mapping <- csv("codex_final_columns.csv")
    aliases <- lapply(split(mapping,mapping$table),function(rows)
      list(columns=setNames(rows$canonical,rows$source)))
  }
  cache <- new.env(parent=emptyenv())
  function(name) {
    if (!exists(name,cache,inherits=FALSE)) {
      config <- aliases[[name]]
      file <- if (is.null(config$file)) paste0(name,".csv") else config$file
      rows <- csv(file.path(package,"datasets",file))
      if (length(config$columns)) {
        i <- match(names(config$columns),names(rows))
        stopifnot(!anyNA(i))
        names(rows)[i] <- unname(config$columns)
      }
      stopifnot(!anyDuplicated(names(rows)))
      assign(name,rows,cache)
    }
    get(name,cache,inherits=FALSE)
  }
}

business <- function(table) {
  rates <- table("fx_rates")
  rate <- setNames(num(rates$eur_rate),key(rates$month,rates$currency))
  fx <- function(date,currency) {
    result <- unname(rate[key(substr(date,1,7),currency)])
    result[currency=="EUR"] <- 1
    if (anyNA(result)) stop("Missing FX rate")
    result
  }
  a <- subset(table("accounts"),!flag(is_test_account))
  c <- subset(table("customers"),!flag(is_test_customer) & account_id %in% a$account_id)
  email <- tolower(trimws(c$email))
  local <- sub("\\+.*$","",sub("@[^@]+$","",email))
  domain <- sub("^.*@","",email)
  gmail <- domain %in% c("gmail.com","googlemail.com")
  local[gmail] <- gsub(".","",local[gmail],fixed=TRUE)
  domain[gmail] <- "gmail.com"
  c$person <- paste(local,domain,sep="@")
  c <- add(c,a,"account_id",c("segment","industry","account_manager"))
  real <- c[order(stamp(c$signup_date),c$customer_id,method="radix"),]
  real <- real[stamp(real$signup_date)<=ref & !duplicated(real$person),]
  pay <- subset(table("payments"),payment_status_detail=="settled" & stamp(payment_date)<=ref)
  o <- subset(table("orders"),order_id %in% pay$order_id & customer_id %in% c$customer_id &
              stamp(order_date)<=ref & order_status %in% c("completed","shipped") &
              payment_status=="paid" & !flag(fraud_flag) & !flag(is_duplicate))
  o$date <- stamp(o$order_date)
  dims <- c("country","region","account_id","segment","person","acquisition_channel")
  o <- add(o,c,"customer_id",dims)
  items <- subset(table("order_items"),order_id %in% o$order_id)
  items <- add(items,o,"order_id",c(dims,"date","currency","order_level_discount_native"))
  items$pair <- key(items$order_id,items$product_id)
  products <- table("products")
  items <- add(items,products,"product_id",c("product_name","family","standard_cost","cost_currency"))
  history <- table("product_category_history")
  by_product <- split(seq_len(nrow(history)),history$product_id)
  items$category <- vapply(seq_len(nrow(items)),function(i) {
    j <- by_product[[items$product_id[i]]]
    j <- j[stamp(history$valid_from[j])<=items$date[i] & stamp(history$valid_to[j])>=items$date[i]]
    stopifnot(length(j)==1L)
    history$category[j]
  },character(1))
  refunds <- subset(table("refunds"),refund_status=="approved" & stamp(refund_date)<=ref)
  refunds$pair <- key(refunds$order_id,refunds$product_id)
  refunds <- refunds[refunds$pair %in% items$pair,]
  refunds$eur <- num(refunds$refund_amount_native)*fx(refunds$refund_date,refunds$currency)
  refunds$category <- items$category[match(refunds$pair,items$pair)]
  gross <- num(items$quantity)*num(items$unit_price_native)
  pre <- gross-num(items$line_discount_native)
  order_total <- lookup(sum_by(pre,items$order_id),items$order_id)
  weights <- pmax(pre,0)
  weight_total <- lookup(sum_by(weights,items$pair),items$pair)
  order_fx <- fx(items$date,items$currency)
  items$gross <- gross*order_fx
  items$line_discount <- (gross-pre)*order_fx
  items$discount <- ifelse(order_total==0,0,num(items$order_level_discount_native)*pre/order_total*order_fx)
  shares <- ifelse(weight_total>0,weights/weight_total,1/lookup(base::table(items$pair),items$pair))
  items$refund <- lookup(sum_by(refunds$eur,refunds$pair),items$pair)*shares
  items$net <- items$gross-items$line_discount-items$discount-items$refund
  items$margin <- items$net-num(items$quantity)*num(items$standard_cost)*fx(items$date,items$cost_currency)
  o$net <- lookup(sum_by(items$net,items$order_id),o$order_id)
  o <- o[order(o$date,o$order_id,method="radix"),]
  tickets <- subset(table("support_tickets"),customer_id %in% c$customer_id & stamp(opened_at)<=ref)
  tickets <- add(tickets,c,"customer_id",dims)
  tickets$date <- stamp(tickets$opened_at)
  tickets$unresolved <- tickets$resolved_at=="" | stamp(tickets$resolved_at)>ref
  elapsed <- seconds(ifelse(tickets$unresolved,ref,tickets$resolved_at))-seconds(tickets$date)
  tickets$breach <- elapsed/3600 > c(urgent=24,high=48,medium=72,low=120)[tickets$priority]
  late <- subset(table("shipments"),order_id %in% o$order_id & stamp(shipped_at)<=ref)
  late <- add(late,o,"order_id",c(dims,"net"))
  late$delivered <- ifelse(late$delivered_at!="" & stamp(late$delivered_at)<=ref,stamp(late$delivered_at),"")
  late$delay <- as.numeric(as.Date(substr(ifelse(late$delivered=="",ref,late$delivered),1,10))-
                           as.Date(substr(late$promised_delivery_date,1,10)))
  late <- late[late$delay>0 & stamp(late$promised_delivery_date)<ref,]
  touches <- subset(table("marketing_touches"),customer_id %in% c$customer_id & stamp(touch_date)<=ref)
  touches <- add(touches,c,"customer_id","person")
  touches$date <- stamp(touches$touch_date)
  person_orders <- split(seq_len(nrow(o)),o$person)
  person_net <- sum_by(o$net,o$person)
  account_net <- sum_by(o$net,o$account_id)
  latest <- tapply(o$date,o$person,max)
  real$net <- lookup(person_net,real$person)
  real$last <- lookup(latest,real$person,"")
  real$orders <- lookup(base::table(o$person),real$person)
  risk <- subset(real,net>=2500 & last!="" & seconds(last)<seconds(ref)-75*86400 &
                   person %in% tickets$person[tickets$unresolved])
  list(a=a,c=c,real=real,o=o,i=items,p=products,t=tickets,s=late,m=touches,r=refunds,
       risk=risk, person_orders=person_orders, account_net=account_net, table=table,fx=fx)
}
revenue_trace <- function(b,country="Germany",quarter="Q4") {
  x <- b$i[b$i$country==country & period(b$i$date,quarter),]
  c(orders=length(unique(x$order_id)),items=nrow(x),
    colSums(x[c("gross","line_discount","discount","refund","net")]))
}
