# Run from the solution R RStudio project. All records below are synthetic.
source("codex_solve.R")

simulate_data <- function(package,seed=5L) {
  set.seed(seed)
  price <- sample(60:100,1)
  folder <- file.path(package,"datasets")
  dir.create(folder,recursive=TRUE)
  write <- function(name,...) {
    rows <- data.frame(...,stringsAsFactors=FALSE)
    write.csv(rows,file.path(folder,paste0(name,".csv")),row.names=FALSE)
  }

  # Duplicate settled payments qualify the same order only once.
  write("accounts",account_id="A",is_test_account=0,segment="SMB",industry="Retail",account_manager="Alex")
  write("customers",customer_id="C",account_id="A",email="demo@example.org",is_test_customer=0,
        signup_date="2024-01-01",country="Germany",region="Central Europe",acquisition_channel="Organic")
  write("orders",order_id="O",customer_id="C",order_date="2024-11-01",order_status="completed",
        payment_status="paid",fraud_flag=0,is_duplicate=0,currency="EUR",order_level_discount_native=5)
  write("payments",payment_id=c("P1","P2"),order_id="O",payment_date="2024-11-01",payment_status_detail="settled")
  write("products",product_id="SKU",standard_cost=20,cost_currency="EUR",product_name="Demo item",family="Hardware")
  write("product_category_history",product_id="SKU",category="Demo",valid_from="2024-01-01",valid_to="2025-01-01")
  write("order_items",order_item_id="L",order_id="O",product_id="SKU",quantity=2,unit_price_native=price,line_discount_native=4)
  write("refunds",refund_id="R",order_id="O",product_id="SKU",refund_date="2024-12-01",currency="USD",
        refund_amount_native=8,refund_status="approved")
  write("fx_rates",month="2024-12",currency="USD",eur_rate=.75)

  # The business loader also prepares support, shipment, and marketing records.
  write("support_tickets",ticket_id="T",customer_id="C",opened_at="2024-11-03",resolved_at="2024-11-04",priority="low")
  write("shipments",shipment_id="S",order_id="O",shipped_at="2024-11-02",delivered_at="2024-11-04",
        promised_delivery_date="2024-11-03")
  write("marketing_touches",touch_id="M",customer_id="C",touch_date="2024-10-30")

  opt <- function(name,...) write(paste0("hard_opt_",name),case_id="OPT",...)
  opt("stock",warehouse_region="W",product_id="SKU",available_units=4)
  opt("dispatch",warehouse_region="W",dispatch_day=1,capacity_units=4)
  opt("suppliers",supplier_id="S",lead_days=1,active=1,minimum_units=4,maximum_units=4,activation_cost_cents=7)
  opt("jobs",job_id=c("J1","J2"),product_id="SKU",quantity=2,ready_day=1,due_day=1,last_day=2,
      late_penalty_cents_per_unit_day=2,unfilled_penalty_cents=100)
  opt("options",job_id=c("J1","J2"),warehouse_region="W",supplier_id="S",dispatch_day=1,variable_cost_cents=10)
  opt("changes",table_name="dispatch",warehouse_region="W",dispatch_day=1,field="capacity_units",new_value=2)

  flow <- function(name,...) write(paste0("flow_",name),case_id="FLOW",...)
  flow("cases",horizon_step=2,knowledge_cutoff_step=0,first_action="SHIFT",first_event_id="cancel",
       first_value=1,second_action="")
  flow("stock",warehouse="W",product_id="SKU",opening_units=0)
  flow("orders",order_id="O",warehouse="W",product_id="SKU",customer_id="C",release_step=1,deadline_step=2,
       units=2,unit_price_cents=100,unit_cost_cents=30,late_penalty_cents=10,unfilled_penalty_cents=20,
       cancellation_fee_cents=5,return_fee_cents=3)
  flow("events",event_id=c("dispatch","receipt","cancel"),event_type=c("DISPATCH","RECEIPT","CANCEL"),
       units=c(2,2,1),recorded_step=0,effective_step=2,version_id="v1",status="posted",
       warehouse="W",product_id="SKU",order_id="O",restock=0)
  write("flow_contracts",case_id=character(),customer_id=character(),recorded_step=integer(),
        version_id=character(),status=character(),priority=integer(),rebate_threshold_units=integer(),
        rebate_per_unit_cents=integer())
  2*price-4-5-8*.75
}

test_run <- function() {
  package <- tempfile("codex_simulated_")
  on.exit(unlink(package,recursive=TRUE))
  expected <- simulate_data(package)
  data <- dataset(package)
  trace <- revenue_trace(business(data),"Germany","Q4")
  stopifnot(trace[["orders"]]==1,trace[["items"]]==1,trace[["net"]]==expected)
  # Each filled job costs 14 cents plus one shared activation fee of 7 cents.
  stopifnot(optimum(data,"OPT")==35,optimum(data,"OPT",TRUE)==200)
  # Moving cancellation past the horizon leaves both units available for dispatch.
  stopifnot(replay(data,"FLOW")==75,replay(data,"FLOW",TRUE)==140)
  cat(sprintf("PASS: revenue EUR %.2f, optimization 35 / 200 cents, replay 75 / 140 cents\n",trace[["net"]]))
}

test_run()
