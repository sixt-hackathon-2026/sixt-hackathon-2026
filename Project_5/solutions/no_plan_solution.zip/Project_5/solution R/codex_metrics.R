#Asnwering questions 1-100

attributed_rows <- function(b) {
  # Pick the latest eligible touch for each order. Resolve ties by campaign and touch ID.
  touch <- b$m
  groups <- split(seq_len(nrow(touch)),touch$person)
  winners <- vapply(seq_len(nrow(b$o)),function(j) {
    idx <- groups[[b$o$person[j]]]
    idx <- idx[window(touch$date[idx],b$o$date[j],30)]
    if (!length(idx)) return(NA_integer_)
    idx[order(-seconds(touch$date[idx]),touch$campaign[idx],touch$touch_id[idx],method="radix")[1]]
  },integer(1))
  orders <- which(!is.na(winners))
  rows <- touch[winners[orders],]
  rows$order_index <- orders
  rows
}

legacy <- function(b,q) {
  o <- b$o; i <- b$i; t <- b$t; s <- b$s; real <- b$real
  rev <- function(field,value,p) sum(o$net[o[[field]]==value & period(o$date,p)])
  z <- function(region,month) {
    v <- sapply(sprintf("2024-%02d",1:9),function(p) rev("region",region,p))
    div(rev("region",region,month)-mean(v),sqrt(mean((v-mean(v))^2)))
  }
  delay <- function(x) div(sum(x$net*x$delay),sum(x$net))
  grouped <- function(x,col,fun) {
    g <- split(seq_len(nrow(x)),x[[col]])
    pick(vapply(g,function(j) fun(x[j,]),numeric(1)))
  }
  cohort <- function(g,month) Filter(function(j) startsWith(o$date[j[1]],month),g)
  if (length(m <- match_q("average number of days between touch and order for campaign (.+?)\\?",q))) {
    rows <- b$attributed[b$attributed$campaign==m[1],]
    return(div(sum(seconds(o$date[rows$order_index])-seconds(rows$date))/86400,nrow(rows)))
  }
  if (length(m <- match_q("latest approved refund date for valid order items in the (.+?) category",q))) {
    dates <- stamp(b$r$refund_date[b$r$category==m[1]])
    return(if (length(dates)) substr(max(dates),1,10) else NA_character_)
  }
  if (length(m <- match_q("How many valid orders were placed by customers in (.+?) during (2024-\\d\\d)",q)))
    return(sum(o$country==m[1] & period(o$date,m[2])))
  if (length(m <- match_q("For (.+?), what is Q4 2024 net revenue from valid orders whose resolved customer",q))) {
    # Qualify people across aliases and all periods before selecting the raw order country.
    eligible <- intersect(s$person,t$person[t$unresolved & t$breach])
    eligible <- intersect(eligible,names(b$person_orders)[lengths(b$person_orders)>=2])
    return(sum(o$net[o$person %in% eligible & o$country==m[1] & period(o$date,"Q4")]))
  }
  if (length(m <- match_q("For (.+?), aggregate lifetime valid-order net revenue by resolved customer",q))) {
    rows <- o[m[1]=="All regions" | o$region==m[1],]
    net <- sum_by(rows$net,rows$person)
    positive <- net[net>0]
    ranked <- order(-positive,names(positive),method="radix")
    return(pct(sum(positive[head(ranked,ceiling(length(positive)/10))]),sum(positive)))
  }
  if (length(m <- match_q("For marketing channel (.+?), calculate 100",q))) {
    # Sum each source at its own grain so multiple shipments do not multiply item margin.
    ids <- o$order_id[b$attributed$order_index[b$attributed$marketing_channel==m[1]]]
    margin <- sum(i$margin[i$order_id %in% ids])
    ship <- subset(b$table("shipments"),order_id %in% ids & stamp(shipped_at)<=ref)
    shipping <- sum(num(ship$shipping_cost_native)*b$fx(ship$shipped_at,ship$currency))
    touches <- b$m[b$m$marketing_channel==m[1],]
    spend <- sum(num(touches$cost_native)*b$fx(touches$date,touches$currency))
    return(pct(margin-shipping-spend,spend))
  }
  if (length(m <- match_q("first valid order was in (2024-\\d\\d).*at least (\\d+) complete days",q))) {
    days <- num(m[2])
    g <- Filter(function(j) seconds(o$date[j[1]])<=seconds(ref)-days*86400,cohort(b$person_orders,m[1]))
    retained <- vapply(g,function(j) any(o$date[j]>o$date[j[1]] & window(o$date[j[1]],o$date[j],days)),logical(1))
    return(pct(sum(retained),length(g)))
  }
  if (length(m <- match_q("For valid orders in (.+?), by how many EUR would total net revenue change",q))) {
    refunds <- add(b$r,o,"order_id",c("date","region"))
    refunds <- refunds[m[1]=="All regions" | refunds$region==m[1],]
    # Refunds are subtracted from revenue, so the delta is actual less hypothetical refunds.
    return(sum(refunds$eur-num(refunds$refund_amount_native)*b$fx(refunds$date,refunds$currency)))
  }
  if (length(m <- match_q("In the (.+?) customer region, among support tickets",q))) {
    ship <- s[s$region==m[1] & s$delivered!="",]
    deliveries <- split(ship$delivered,ship$person)
    eligible <- vapply(seq_len(nrow(t)),function(j) any(window(deliveries[[t$person[j]]],t$date[j],14)),logical(1))
    return(pct(sum(t$breach[eligible]),sum(eligible)))
  }
  if (length(m <- match_q("For late shipments handled by (.+?),",q))) return(delay(s[s$carrier==m[1],]))
  if (length(m <- match_q("late shipments linked to valid orders in the (.+?) customer region",q)))
    return(grouped(s[s$region==m[1],],"carrier",delay))
  if (length(m <- match_q("items in the (.+?) category(?: during (Q\\d) 2024)?, what was the (margin rate|approved-refund rate)",q))) {
    rows <- i[i$category==m[1] & (m[2]=="" | period(i$date,m[2])),]
    if (m[3]=="margin rate") return(pct(sum(rows$margin),sum(rows$net)))
    return(pct(sum(rows$refund),sum(rows$gross)))
  }
  if (length(m <- match_q("net revenue in EUR from customers in (.+?) during (Q\\d)",q))) return(rev("country",m[1],m[2]))
  if (length(m <- match_q("For customers in (.+?), what was the percentage growth",q))) {
    a <- rev("country",m[1],"Q3"); return(pct(rev("country",m[1],"Q4")-a,a))
  }
  if (length(m <- match_q("Did net revenue in the (.+?) region .* at least (\\d+)%",q))) {
    a <- rev("region",m[1],"Q3"); return(a!=0 && pct(rev("region",m[1],"Q4")-a,a)>=num(m[2]))
  }
  if (grepl("manager owns the largest",q,fixed=TRUE)) return(pick(sum_by(b$risk$net,b$risk$account_manager)))
  if (grepl("normalized email domain",q,fixed=TRUE)) return(pick(sum_by(o$net,sub("^.*@","",o$person))))
  if (length(m <- match_q("During (Q\\d) 2024, which product category had the highest margin",q)))
    return(grouped(i[period(i$date,m[1]),],"category",function(x) div(sum(x$margin),sum(x$net))))
  if (length(m <- match_q("For the (.+?) region in (Q\\d) 2024, what was net revenue as a percentage",q))) {
    x <- b$table("sales_targets")
    return(pct(rev("region",m[1],m[2]),sum(num(x$net_revenue_target_eur[x$region==m[1] & period(x$month,m[2])]))))
  }
  if (length(m <- match_q("accounts in the (.+?) industry had at least one late",q)))
    return(sum(b$a$industry==m[1] & b$a$account_id %in% intersect(s$account_id,t$account_id[t$breach])))
  if (length(m <- match_q("for the (.+?) customer region during (2024-\\d\\d)",q))) return(rev("region",m[1],m[2]))
  if (length(m <- match_q("accounts in the (.+?) segment, what is the 90th percentile",q)))
    return(unname(quantile(lookup(b$account_net,b$a$account_id[b$a$segment==m[1]]),.9,type=7)))
  if (length(m <- match_q("For the (.+?) region, what is the z-score of (2024-\\d\\d)",q))) return(z(m[1],m[2]))
  if (length(m <- match_q("Which region had the highest net-revenue z-score in (2024-\\d\\d)",q)))
    return(pick(sapply(unique(b$c$region),z,month=m[1])))
  if (length(m <- match_q("high-value accounts in the (.+?) segment, which issue",q)))
    return(pick(table(t$issue_type[t$segment==m[1] & lookup(b$account_net,t$account_id)>=7000])))
  if (length(m <- match_q("first valid order occurred in (2024-\\d\\d).*within (\\d+) days",q))) {
    g <- cohort(b$person_orders,m[1])
    return(pct(sum(vapply(g,function(j) length(j)>1 && window(o$date[j[1]],o$date[j[2]],num(m[2])),logical(1))),length(g)))
  }
  if (length(m <- match_q("from accounts in the (.+?) segment during (Q\\d)",q))) {
    x <- i[i$segment==m[1] & period(i$date,m[2]),]; return(pick(sum_by(x$net,x$category)))
  }
  if (length(m <- match_q("highest-lifetime-revenue account in the (.+?) segment.*from the (.+?) category",q))) {
    ids <- b$a$account_id[b$a$segment==m[1]]
    id <- pick(setNames(lookup(b$account_net,ids),ids))
    return(pct(sum(i$net[i$account_id==id & i$category==m[2]]),lookup(b$account_net,id)))
  }
  if (grepl("Pearson correlation",q,fixed=TRUE)) {
    gross <- sum_by(i$gross,i$category)
    return(cor(sum_by(i$line_discount,i$category)/gross,sum_by(i$refund,i$category)/gross))
  }
  if (length(m <- match_q("traffic source '(.+?)'",q))) {
    sessions <- b$table("web_sessions")
    sessions <- sessions[sessions$traffic_source==m[1] & sessions$customer_id %in% b$c$customer_id &
                         stamp(sessions$session_date)<=ref,]
    sessions <- add(sessions,b$c,"customer_id","person")
    g <- split(sessions$session_date,sessions$person)
    hit <- vapply(names(g),function(p) any(vapply(g[[p]],function(d) any(window(d,o$date[b$person_orders[[p]]],14)),logical(1))),logical(1))
    return(pct(sum(hit),length(g)))
  }
  if (length(m <- match_q("marketing channel was (.+?)\\?",q))) {
    rows <- b$attributed[b$attributed$marketing_channel==m[1],]
    return(pick(sum_by(o$net[rows$order_index],rows$campaign)))
  }
  if (length(m <- match_q("items from customers in (.+?), which product category had the highest approved-refund",q)))
    return(grouped(i[i$country==m[1],],"category",function(x) div(sum(x$refund),sum(x$gross))))
  if (length(m <- match_q("Did (.+?) meet or exceed its net revenue target in (2024-\\d\\d)",q))) {
    x <- b$table("sales_targets")
    return(rev("country",m[1],m[2])>=sum(num(x$net_revenue_target_eur[x$country==m[1] & x$month==m[2]])))
  }
  if (length(m <- match_q("at-risk real customers are in (.+?)\\?",q))) return(sum(b$risk$country==m[1]))
  if (length(m <- match_q("For customers in (.+?) who opened at least one support ticket",q))) {
    first <- tapply(t$date,t$person,min)
    x <- i[i$country==m[1] & i$date<lookup(first,i$person,""),]
    return(pick(sum_by(x$net,x$category)))
  }
  if (length(m <- match_q("median net revenue per valid order for accounts in the (.+?) segment",q))) return(median(o$net[o$segment==m[1]]))
  if (length(m <- match_q("unique real customers are in (.+?)\\?",q))) return(sum(real$country==m[1]))
  if (length(m <- match_q("eligible touch for campaign (.+?) and .* issue type (.+?)\\?",q))) {
    ids <- intersect(b$m$person[b$m$campaign==m[1]],t$person[t$issue_type==m[2]])
    return(sum(o$net[o$person %in% ids]))
  }
  if (length(m <- match_q("In the (.+?) region during (Q\\d).*top 3 product categories",q))) {
    x <- i[i$region==m[1] & period(i$date,m[2]),]; return(pick(sum_by(x$net,x$category),3))
  }
  if (length(m <- match_q("raw customer's acquisition channel was (.+?)\\?",q))) {
    dates <- o$date[o$acquisition_channel==m[1]]
    return(if (length(dates)) substr(min(dates),1,10) else NA_character_)
  }
  if (length(m <- match_q("customers in the (.+?) region during (2024-\\d\\d), which product name",q))) {
    x <- i[i$region==m[1] & period(i$date,m[2]),]; return(pick(sum_by(x$net,x$product_name)))
  }
  if (length(m <- match_q("real customers acquired through (.+?), what percentage converted",q))) {
    x <- real[real$acquisition_channel==m[1] & real$trial_start_date!="" & stamp(real$trial_start_date)<=ref,]
    first <- tapply(o$date,o$person,min)
    return(pct(sum(window(x$trial_start_date,lookup(first,x$person,""),30)),nrow(x)))
  }
  if (length(m <- match_q("support tickets with priority '(.+?)'",q))) {
    x <- t$breach[t$priority==m[1]]; return(pct(sum(x),length(x)))
  }
  if (length(m <- match_q("active real customers are in the (.+?) region",q)))
    return(sum(real$region==m[1] & real$orders>=2 & seconds(real$last)>=seconds(ref)-90*86400,na.rm=TRUE))
  stop("Unmapped legacy question")
}
