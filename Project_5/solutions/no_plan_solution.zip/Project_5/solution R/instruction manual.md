# Instruction manual

## 1. Open the RStudio project

Open `solution R.Rproj` in RStudio. This sets the working directory so the relative paths below work. The code uses Base R. The competition packages should be in the sibling folders `problem7_student_start` and `problem7_student_final`.

## 2. Load the code and check the worked examples

Run these lines in the RStudio console:

```r
source("codex_solve.R")
revenue_trace(business(dataset("../problem7_student_start")))
View(solve(examples = TRUE))
source("codex_validate.R")
validate()
```

The trace shows E001's intermediate totals. The example table should show `TRUE` for all ten checks. The validation script also compares the existing R and Python Stage 1 answers.

## 3. Inspect or regenerate the competition answers

```r
View(csv("public_answers.csv"))
View(csv("final_answers.csv"))

public <- solve(output = "codex_public_reproduced.csv")
final <- solve("../problem7_student_final", "final_questions.csv", "codex_final_reproduced.csv")
View(final)
```

The final loader automatically applies the included column mapping. The pure R optimizer can take a while on the final cases. If you have built the optional executable using the Python README, run `Sys.setenv(CODEX_INTEGER_SEARCH = normalizePath("../solution python/codex_integer_search.exe"))` before recalculating. The commands above write separate output files for comparison.

## 4. Run the synthetic demo

```r
source("codex_simulated_demo.R")
```

Sourcing the script generates temporary CSVs and runs the checks at the end of the file. The expected line starts with `PASS: revenue EUR 107.00`. Optimization gives 35 and 200 cents. Event replay gives 75 and 140 cents.

To keep the generated tables available for inspection during your R session, run:

```r
package <- tempfile("codex_simulated_")
expected <- simulate_data(package, seed = 5L)
data <- dataset(package)
View(data("orders"))
View(data("flow_events"))
trace <- revenue_trace(business(data), "Germany", "Q4")
stopifnot(trace[["net"]] == expected)
print(trace)
optimum(data, "OPT")
replay(data, "FLOW", TRUE)
```

Change the seed to generate a different unit price. `list.files(file.path(package, "datasets"), full.names = TRUE)` shows the generated CSV paths. The miniature dataset exercises three calculation engines directly.
