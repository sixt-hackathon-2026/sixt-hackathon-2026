source("codex_solve.R")

validate <- function(compare=TRUE) {
  data <- dataset("../problem7_student_start")
  b <- operations(business(data))
  pay <- subset(data("payments"),payment_status_detail=="settled" & stamp(payment_date)<=ref)
  repeated <- intersect(pay$order_id[duplicated(pay$order_id)],b$o$order_id)
  actual <- b$i$order_item_id[b$i$order_id %in% repeated]
  source_items <- data("order_items")
  expected <- source_items$order_item_id[source_items$order_id %in% repeated]
  stopifnot(length(repeated)>0,identical(sort(actual),sort(expected)))
  allocated <- sum_by(b$i$refund,b$i$pair)
  refunds <- sum_by(b$r$eur,b$r$pair)
  stopifnot(max(abs(allocated[names(refunds)]-refunds))<1e-8,
            all(stamp(b$r$refund_date)<=ref),
            all(b$r$eur==num(b$r$refund_amount_native)*b$fx(b$r$refund_date,b$r$currency)),
            b$fx(ref,"EUR")==1,
            inherits(try(b$fx(ref,"UNKNOWN"),silent=TRUE),"try-error"),
            period("2024-10-01 00:00:00","Q4"),!period(ref,"Q4"),
            window("2024-01-01","2024-01-15",14),!window("2024-01-01","2024-01-15 00:00:01",14),
            answer_format(10.125,"number")=="10.12",answer_format(10.135,"number")=="10.14")
  versions <- data.frame(event_id="e",recorded_step=c(1,1,2),version_id=c("v9","v10","v1"),
                         status=c("void","posted","posted"))
  stopifnot(known(versions,"event_id",1)$status=="void",
            known(versions[3:1,],"event_id",1)$status=="void")

  event <- function(id,type,units) data.frame(case_id="test",event_id=id,event_type=type,effective_step=2,
    units=units,recorded_step=0,version_id="v1",status="posted",warehouse="W",product_id="P",
    order_id="O",restock="false")
  tables <- list(
    flow_cases=data.frame(case_id="test",horizon_step=2,knowledge_cutoff_step=0,first_action="SHIFT",
                          first_event_id="cancel",first_value=1,second_action=""),
    flow_contracts=data.frame(case_id=character(),customer_id=character(),recorded_step=integer(),
                              version_id=character(),status=character(),priority=integer(),
                              rebate_threshold_units=integer(),rebate_per_unit_cents=integer()),
    flow_stock=data.frame(case_id="test",warehouse="W",product_id="P",opening_units=0),
    flow_orders=data.frame(case_id="test",order_id="O",warehouse="W",product_id="P",customer_id="C",
      units=2,release_step=1,deadline_step=2,unit_price_cents=100,unit_cost_cents=30,late_penalty_cents=10,
      unfilled_penalty_cents=20,cancellation_fee_cents=5,return_fee_cents=3),
    flow_events=rbind(event("dispatch","DISPATCH",2),event("receipt","RECEIPT",2),
                      event("cancel","CANCEL",1),event("return","RETURN",1)),
    hard_opt_stock=data.frame(case_id="test",warehouse_region="W",product_id="P",available_units=4),
    hard_opt_dispatch=data.frame(case_id="test",warehouse_region="W",dispatch_day=0,capacity_units=4),
    hard_opt_suppliers=data.frame(case_id="test",supplier_id="S",lead_days=1,active="1",minimum_units=4,
                                 maximum_units=4,activation_cost_cents=7),
    hard_opt_jobs=data.frame(case_id="test",job_id=c("A","B"),product_id="P",quantity=2,ready_day=0,due_day=0,
                             last_day=1,late_penalty_cents_per_unit_day=2,unfilled_penalty_cents=100),
    hard_opt_options=data.frame(case_id="test",job_id=c("A","B"),warehouse_region="W",supplier_id="S",
                                dispatch_day=0,variable_cost_cents=10),
    hard_opt_changes=data.frame(case_id="test",table_name="dispatch",warehouse_region="W",dispatch_day=0,
                                field="capacity_units",new_value="2"))
  fixture <- function(name) tables[[name]]
  stopifnot(replay(fixture,"test")==75,replay(fixture,"test",TRUE)==140,
            optimum(fixture,"test")==35,optimum(fixture,"test",TRUE)==200)
  examples <- solve(examples=TRUE)
  stopifnot(nrow(examples)==10,isTRUE(all(examples$ok)))
  if (compare) {
    python <- csv("../solution python/public_answers.csv")
    r <- csv("public_answers.csv")
    stopifnot(nrow(r)==200,identical(r,python),all(nzchar(r$answer)))
    cat("200 R answers agree with Python.\n")
  }
  cat("10 worked examples and targeted checks passed.\n")
  invisible(examples)
}

if (sys.nframe()==0L) validate()
