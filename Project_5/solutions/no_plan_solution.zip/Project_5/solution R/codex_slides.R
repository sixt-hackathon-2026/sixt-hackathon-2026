source("codex_solve.R")
dir.create("submission",showWarnings=FALSE)
pdf("submission/slides.pdf",width=13.333,height=7.5,paper="special",
    title="Project 5 - RStudio",encoding="WinAnsi.enc")
par(mar=c(0,0,0,0),xaxs="i",yaxs="i",family="sans")
ink <- "#171A1D"; orange <- "#C43E0A"; muted <- "#515964"
line <- function(y,label,cex=1.25,col=ink,font=1,x=.06) {
  Encoding(label) <- "UTF-8"
  text(x,y,label,adj=c(0,.5),cex=cex,col=col,font=font)
}
slide <- function(title,sub) {
  plot.new(); plot.window(c(0,1),c(0,1))
  line(.9,"SIXT + TUM  /  PROJECT 5",1.05,orange,2)
  line(.78,title,2.5,ink,2); line(.70,sub,1.3,muted)
}
points_text <- function(titles,details) {
  for (i in seq_along(titles)) {
    y <- .56-(i-1)*.15
    line(y,titles[i],1.55,ink,2); line(y-.065,details[i],1.15,muted)
  }
}
slide("From Orders to Verified Answers","Stage 1 · Calculated in Base R")
points_text(c("150 business metrics","30 cost optimization questions","20 simulation questions"),
            c("Eligible orders, procurement, inventory, and returns",
              "Exact search over whole jobs and available capacity",
              "Select known event versions and replay them in chronological order"))
slide("E001 · Net Revenue in Germany","Q4 2024 · 83 orders · 246 line items")
points_text(c("orders, customers, accounts","payments and order_items","refunds and fx_rates"),
            c("Use the customer linked to the order and exclude test records.",
              "Settled payments qualify an order once.",
              "Use order-month FX for prices and discounts and refund-month FX for refunds."))
trace <- revenue_trace(business(dataset("../problem7_student_start")))
en <- function(x,d) formatC(x,format="f",digits=d,big.mark=",",decimal.mark=".")
slide(paste("EUR",en(trace[["net"]],2)),"E001 · Round the final total")
for (i in seq_along(labels <- c("Gross revenue","Line discounts","Order discounts","Approved refunds"))) {
  y <- .58-(i-1)*.09
  line(y,labels[i]); line(y,paste0(if (i>1) "- " else "",en(trace[2+i],8)),1.25,ink,2,.56)
}
line(.13,'revenue_trace(business(dataset("../problem7_student_start")))',1.15,orange,2)
slide("Validation and Reproduction","Base R runs all calculations locally")
points_text(c("10 worked examples","Boundary and scenario checks","RStudio"),
            c("All examples match the answers in the released package.",
              "Checks cover payments, FX, rounding, supplier constraints, and event order.",
              'Open the project and run source("codex_solve.R").'))
if (dir.exists("../problem7_student_final")) {
  trace <- revenue_trace(business(dataset("../problem7_student_final")),"France","Q3")
  slide("F004 · Net Revenue in France",
        sprintf("Q3 2024 · %d orders · %d line items",trace[["orders"]],trace[["items"]]))
  labels <- c("Gross revenue","Line discounts","Order discounts","Approved refunds")
  for (i in seq_along(labels)) {
    y <- .58-(i-1)*.09
    line(y,labels[i])
    line(y,en(trace[2+i],8),1.25,ink,2,.56)
  }
  line(.13,paste("Net revenue: EUR",en(trace[["net"]],2)),1.5,orange,2)
}
invisible(dev.off())
