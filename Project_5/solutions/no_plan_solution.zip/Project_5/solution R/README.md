# Project 5 in RStudio

Open `solution R.Rproj` in RStudio. The workflow uses Base R. The released package is in the sibling `problem7_student_start/` directory.

```r
source("codex_solve.R")

# Recalculate E001 and show its subtotals
revenue_trace(business(dataset("../problem7_student_start")))

# Recalculate the worked examples and inspect the results
examples <- solve(examples = TRUE)
View(examples)

# Recalculate all 200 answers and open the results in the Data Viewer
answers <- solve(output = "public_answers.csv")
View(answers)

source("codex_validate.R")
validate()
```

Exact optimization can take several minutes. To inspect the existing answers immediately, run `View(csv("public_answers.csv"))`. From a terminal in this folder, you can also use `Rscript codex_solve.R --examples`, `Rscript codex_solve.R`, and `Rscript codex_validate.R`.

- `codex_data.R` loads the CSVs, identifies valid orders, and calculates revenue.
- `codex_metrics.R` and `codex_operations.R` calculate business metrics.
- `codex_scenarios.R` implements the integer search and event simulation.
- `source("codex_slides.R")` regenerates `submission/slides.pdf`.

## Stage 2

```r
source("codex_solve.R")
View(csv("final_answers.csv"))
revenue_trace(business(dataset("../problem7_student_final")), "France", "Q3")

# Optional speed-up for the exact optimizer. See the Python README for build commands.
Sys.setenv(CODEX_INTEGER_SEARCH = normalizePath("../solution python/codex_integer_search.exe"))
final <- solve("../problem7_student_final", "final_questions.csv", "codex_final_reproduced.csv")
View(final)
```

Base R implements all three calculation blocks. It also supports the optional compiled search used in the verified final run. Without the executable, unset `CODEX_INTEGER_SEARCH` to use the Base R search. The final loader applies `codex_final_columns.csv` automatically.
