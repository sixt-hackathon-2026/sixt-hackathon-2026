# Project 5 method report

**Team name** No Plan is a plan

**Team member and contributions** Andreas Schebrak. Individual contributions have yet to be recorded.

**Public submission** `public_answers.csv`, SHA-256 `bb90ec65310bd902224f694ce1e815045bf1a52dc9f3101aa08a4d5a11b10b41`.

**Final submission** `final_answers.csv`, SHA-256 `66e4208ebddf017078090b3448770ba94225fb80defe6c2a5db013514862cca6`.

**Code revision used for calculations** Pending. Record the solver commit SHA before committing the report update.

## 1. Approach

We gave OpenAI Codex the challenge rules, used basic questions to check its interpretation, and then asked it to implement and validate the calculations. The solver reads the released tables and produces one scalar answer per question. A team member reviews the results and submits the answer CSVs.

## 2. Architecture and implementation

```text
Released questions and dataset
              |
        codex_solve.R
              |
  +-----------+-----------+
  |           |           |
Business    Exact       Event
metrics   optimization  replay
  +-----------+-----------+
              |
      question_id,answer
```

Questions 001–150 in each stage use business and operations metrics. Questions 151–180 use the `hard_opt_*` tables for baseline and counterfactual optimization. Questions 181–200 use the `flow_*` tables for baseline and what-if replay. Stage 2 is a separate data snapshot. The loader maps its 79 renamed headers through `codex_final_columns.csv` before applying the rules. Final-stage recipes also cover identity-level eligibility, fully observed cohorts, and a refund FX counterfactual.

`codex_solve.R` dispatches by question ID and wording. `codex_data.R` loads the required tables and applies order eligibility, customer identity resolution, currency conversion, discounts, and approved-refund rules. `codex_metrics.R` and `codex_operations.R` calculate the business metrics. `codex_scenarios.R` solves whole-job allocations in integer cents and replays the event versions known at each case’s cutoff. `codex_validate.R` checks the worked examples and targeted cases. `codex_simulated_demo.R` runs a small synthetic dataset through all three calculation engines.

Open `solution R.Rproj` in RStudio with both released packages unpacked alongside the solution folder. The workflow was verified with Base R 4.6.2. Run the following in the R console.

```r
source("codex_solve.R")
source("codex_validate.R")
validate()
source("codex_simulated_demo.R")
public <- solve(output = "codex_public_reproduced.csv")
Sys.setenv(CODEX_INTEGER_SEARCH = normalizePath("../solution python/codex_integer_search.exe"))
final <- solve("../problem7_student_final", "final_questions.csv", "codex_final_reproduced.csv")
```

The official submission paths and hashes above refer to the files in `Project_5`. The R exports have different CSV quoting and the same answer values.

The verified final run used the included Windows executable built from `codex_integer_search.cs`. The [Python README](../solution%20python/README.md) provides the build command. The automatic grader reads the two submission CSVs in `Project_5`.

## 3. Validation and results

All ten released worked examples passed. Targeted checks confirm that multiple eligible settled payments qualify an order only once, so payment rows cannot duplicate its items. Allocated refunds reconcile by order and product. Refunds are checked against the reporting cutoff and converted using refund-date FX. EUR uses a rate of 1, and missing exchange rates raise an error.

The checks cover quarter boundaries, exact elapsed windows, and ties-to-even rounding at half-cent values. Scenario fixtures cover selection of known void versions, same-step action ordering, and supplier activation and minimums under changed dispatch capacity. The replay selects the known version before applying its void status, so a void version removes the event.

Fresh runs reproduced all 200 submitted answer values per stage in both languages. The final runs shared the C# search, so agreement on those optimization answers checks reproducibility. Both implementations calculated EUR 372,881.74 for F004 across 101 orders and 304 items. The official checker accepted both submission CSVs with 200 nonblank answers each. Its feedback covers CSV structure. Scored-answer accuracy awaits official grading.

The R workflow normalizes timestamps that omit seconds before calculating elapsed time.

## 4. Model use and efficiency

OpenAI Codex assisted with rule interpretation, implementation, debugging, and validation design for both stages. Base R generated the answers and RStudio provided the development environment. The final run used the shared C# optimizer. The exact Codex serving revision and runtime settings were unavailable. Hardware, runtime, token usage, memory use, and cost were not measured for this report. [Model declaration](MODEL_DECLARATION.csv) · [Codex evidence](codex_model_evidence.md)

## 5. Small-model bonus declaration

Bonus claimed **no**. Eligibility under the 40B total-parameter threshold is unverified. The exact serving revision and parameter count were unavailable.

## 6. Limitations and reflection

The dispatcher relies on recognized question wording. Changes to wording or business rules can require new or revised recipes. The number of jobs and feasible assignments affects exact-search runtime. SIXT could use the same structure for as-of reporting and dispatch comparisons governed by explicit eligibility and versioning rules.

## 7. References and attribution

Ioannis Tzachristas (2026). *Enterprise Data Agent Challenge 2026: multi-table calculations, constrained allocation and event replay*. Version 7.0.0. Unpublished local dataset.

- **Stage 1** `problem7_student_start.zip`, accessed 2026-11-13. SHA-256 `dcab020fd06195bcb60c92a61ed450296e2fed81f401ad4aeb5aa98b5cbcf7e0`.
- **Stage 2** `problem7_student_final.zip`, accessed 2026-11-13. SHA-256 `59417f1adf04e08a328c42c6f54450933b3032b0d0ff1398cfc01d2a169738da`.

The workflow uses Base R 4.6.2 and RStudio, the project’s C# optimizer, and OpenAI Codex desktop for development and validation.

## Presentation preparation

The demo traces E001 and F004 from eligible orders through FX conversion, discounts, and approved refunds. Regenerate it from the RStudio project with `source("codex_slides.R")`. [Demo slides](submission/slides.pdf)

## 8. Publication follow-up after the Hackathon

Coordination with Ioannis Tzachristas (ioannis.tzachristas@tum.de) is pending. Agree on the manuscript title, authorship, dataset citation, content, and timing before uploading. Use public toy examples and authorized figures in the manuscript. Record the reviewed version and send the organizers the upload confirmation, submission date, and arXiv identifier when available. [LaTeX starter](../problem7_student_final/arxiv_report/README.md)
