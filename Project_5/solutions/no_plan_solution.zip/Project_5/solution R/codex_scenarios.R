case_rows <- function(table,name,id) {
  x <- table(name)
  x[x$case_id==id,,drop=FALSE]
}

optimum <- function(table,id,changed=FALSE) {
  get <- function(name) case_rows(table,paste0("hard_opt_",name),id)
  resources <- list(stock=get("stock"),dispatch=get("dispatch"),suppliers=get("suppliers"))
  keys <- list(stock=function(x) key(x$warehouse_region,x$product_id),
               dispatch=function(x) key(x$warehouse_region,x$dispatch_day),
               suppliers=function(x) x$supplier_id)
  if (changed) {
    # Replace every specified resource field before testing option feasibility.
    changes <- get("changes")
    for (i in seq_len(nrow(changes))) {
      change <- changes[i,]; name <- change$table_name
      target <- match(keys[[name]](change),keys[[name]](resources[[name]]))
      stopifnot(!is.na(target),change$field %in% names(resources[[name]]))
      resources[[name]][[change$field]][target] <- change$new_value
    }
  }
  supplier <- resources$suppliers
  stock <- num(resources$stock$available_units)
  dispatch <- num(resources$dispatch$capacity_units)
  min_units <- num(supplier$minimum_units)
  max_units <- num(supplier$maximum_units)
  fee <- num(supplier$activation_cost_cents)
  used <- numeric(nrow(supplier))
  jobs <- get("jobs"); options <- get("options")
  oi <- match(options$job_id,jobs$job_id)
  si <- match(options$supplier_id,supplier$supplier_id)
  sk <- match(key(options$warehouse_region,jobs$product_id[oi]),keys$stock(resources$stock))
  dk <- match(keys$dispatch(options),keys$dispatch(resources$dispatch))
  day <- num(options$dispatch_day); qty <- num(jobs$quantity)
  arrival <- day+num(supplier$lead_days[si])
  valid <- which(flag(supplier$active[si]) & day>=num(jobs$ready_day[oi]) &
    arrival<=num(jobs$last_day[oi]) & stock[sk]>=qty[oi] &
    dispatch[dk]>=qty[oi] & max_units[si]>=qty[oi])
  cost <- num(options$variable_cost_cents)+qty[oi]*num(jobs$late_penalty_cents_per_unit_day[oi])*
    pmax(0,arrival-num(jobs$due_day[oi]))
  penalties <- num(jobs$unfilled_penalty_cents)
  choices <- lapply(seq_len(nrow(jobs)),function(j) {
    idx <- valid[oi[valid]==j]
    rows <- cbind(cost=c(cost[idx],penalties[j]),stock=c(sk[idx],0),
                  dispatch=c(dk[idx],0),supplier=c(si[idx],0))
    rows[order(rows[,"cost"]),,drop=FALSE]
  })
  job_order <- order(-vapply(choices,function(x) diff(range(x[,"cost"])),numeric(1)),
                     vapply(choices,nrow,integer(1)))
  choices <- choices[job_order]; qty <- qty[job_order]
  n <- length(choices)
  executable <- Sys.getenv("CODEX_INTEGER_SEARCH")
  if (nzchar(executable)) {
    # The optional compiled search receives the same costs and feasible choices as Base R.
    payload <- c(paste(n,length(stock),length(dispatch),length(used)),
                 paste(stock,collapse=" "),paste(dispatch,collapse=" "),
                 paste(min_units,max_units,fee))
    for (j in seq_len(n)) {
      x <- choices[[j]]
      payload <- c(payload,paste(qty[j],nrow(x)),
                   paste(x[,1],x[,2]-1,x[,3]-1,x[,4]-1))
    }
    result <- system2(executable,input=payload,stdout=TRUE)
    if (length(result)!=1L || !grepl("^-?[0-9]+$",result)) stop("Compiled optimization failed")
    return(unname(num(result)))
  }
  lower <- numeric(n+1L)
  reachable <- matrix(0,n+1L,length(used))
  for (j in rev(seq_len(n))) {
    lower[j] <- lower[j+1L]+choices[[j]][1,"cost"]
    reachable[j,] <- reachable[j+1L,]
    ids <- unique(choices[[j]][,"supplier"])
    ids <- ids[ids>0]
    reachable[j,ids] <- reachable[j,ids]+qty[j]
  }
  best <- sum(penalties)
  negative <- which(fee<0)
  choices <- lapply(choices,function(x) list(cost=x[,1],stock=x[,2],dispatch=x[,3],supplier=x[,4]))
  # Every job takes one option or its unfilled penalty. Bounds relax shared capacity.
  visit <- function(j,spent) {
    credit <- if (length(negative)) sum(fee[negative[used[negative]==0 & reachable[j,negative]>0]]) else 0
    if (spent+lower[j]+credit>=best) return(invisible(NULL))
    if (any(used>0 & used+reachable[j,]<min_units)) return(invisible(NULL))
    if (j>n) { best <<- spent; return(invisible(NULL)) }
    # Remaining jobs may independently reuse residual capacity in this lower bound.
    bound <- spent+credit
    for (h in seq.int(j,n)) {
      x <- choices[[h]]
      count <- qty[h]
      for (k in seq_along(x$cost)) {
        sup <- x$supplier[k]
        if (!sup || (stock[x$stock[k]]>=count && dispatch[x$dispatch[k]]>=count &&
                     used[sup]+count<=max_units[sup])) {
          bound <- bound+x$cost[k]
          break
        }
      }
      if (bound+lower[h+1L]>=best) return(invisible(NULL))
    }
    count <- qty[j]
    x <- choices[[j]]
    for (k in seq_along(x$cost)) {
      sup <- x$supplier[k]; st <- x$stock[k]; dp <- x$dispatch[k]
      next_cost <- spent+x$cost[k]
      if (!sup) {
        visit(j+1L,next_cost)
      } else if (stock[st]>=count && dispatch[dp]>=count && used[sup]+count<=max_units[sup]) {
        if (!used[sup]) next_cost <- next_cost+fee[sup]
        stock[st] <<- stock[st]-count
        dispatch[dp] <<- dispatch[dp]-count
        used[sup] <<- used[sup]+count
        visit(j+1L,next_cost)
        used[sup] <<- used[sup]-count
        dispatch[dp] <<- dispatch[dp]+count
        stock[st] <<- stock[st]+count
      }
    }
  }
  visit(1L,0)
  best
}

known <- function(rows,id,cutoff) {
  rows <- rows[num(rows$recorded_step)<=cutoff,,drop=FALSE]
  rows <- rows[order(num(rows$recorded_step),rows$version_id,decreasing=TRUE,method="radix"),,drop=FALSE]
  rows[!duplicated(rows[[id]]),,drop=FALSE]
}

replay <- function(table,id,changed=FALSE) {
  get <- function(name) case_rows(table,paste0("flow_",name),id)
  config <- get("cases")
  stopifnot(nrow(config)==1)
  cutoff <- num(config$knowledge_cutoff_step)
  events <- known(get("events"),"event_id",cutoff)
  terms <- subset(known(get("contracts"),"customer_id",cutoff),status=="active")
  if (changed) for (prefix in c("first","second")) {
    # Modify the selected version before the horizon filter.
    action <- config[[paste0(prefix,"_action")]]
    if (action=="") next
    j <- match(config[[paste0(prefix,"_event_id")]],events$event_id)
    value <- num(config[[paste0(prefix,"_value")]])
    stopifnot(!is.na(j))
    if (action=="SHIFT") events$effective_step[j] <- num(events$effective_step[j])+value
    else if (action=="SET_UNITS") events$units[j] <- value
    else stop("Unknown edit")
  }
  events <- subset(events,status!="void")
  orders <- get("orders")
  actions <- rbind(
    data.frame(step=num(events$effective_step),type=events$event_type,id=events$event_id,row=seq_len(nrow(events))),
    data.frame(step=num(orders$release_step),type="RELEASE",id=orders$order_id,row=seq_len(nrow(orders))))
  priority <- c("CANCEL","RETURN","RECEIPT","RELEASE","DISPATCH")
  actions <- actions[order(actions$step,match(actions$type,priority),actions$id,method="radix"),]
  actions <- actions[actions$step<=num(config$horizon_step),]
  opening <- get("stock")
  order_stock <- key(orders$warehouse,orders$product_id)
  event_stock <- key(events$warehouse,events$product_id)
  stock_keys <- unique(c(key(opening$warehouse,opening$product_id),order_stock,event_stock))
  stock <- lookup(setNames(num(opening$opening_units),key(opening$warehouse,opening$product_id)),stock_keys)
  order_stock <- match(order_stock,stock_keys)
  event_stock <- match(event_stock,stock_keys)
  tier <- lookup(setNames(num(terms$priority),terms$customer_id),orders$customer_id,99)
  queue <- order(tier,num(orders$deadline_step),num(orders$release_step),orders$order_id,method="radix")
  state <- lapply(num(orders$units),function(n) rep("waiting",n))
  # Unit indexes preserve reservation order. Dispatch indexes break ties between dispatches.
  dispatched <- lapply(num(orders$units),integer)
  released <- rep(FALSE,nrow(orders))
  money <- 0
  for (action_number in seq_len(nrow(actions))) {
    a <- actions[action_number,]; j <- a$row
    if (a$type=="RELEASE") {
      released[j] <- TRUE
    } else {
      count <- num(events$units[j])
      if (a$type=="RECEIPT") {
        st <- event_stock[j]
        stock[st] <- stock[st]+count
      } else if (a$type=="DISPATCH") {
        for (i in queue[released[queue] & orders$warehouse[queue]==events$warehouse[j]]) {
          units <- head(which(state[[i]]=="reserved"),count)
          count <- count-length(units)
          state[[i]][units] <- "shipped"
          dispatched[[i]][units] <- action_number
          late <- if (a$step>num(orders$deadline_step[i])) num(orders$late_penalty_cents[i]) else 0
          money <- money+length(units)*(num(orders$unit_price_cents[i])-num(orders$unit_cost_cents[i])-late)
          if (count==0) break
        }
      } else {
        i <- match(events$order_id[j],orders$order_id)
        stopifnot(!is.na(i))
        if (released[i] && a$type=="CANCEL") {
          units <- head(which(state[[i]] %in% c("waiting","reserved")),count)
          st <- order_stock[i]
          stock[st] <- stock[st]+sum(state[[i]][units]=="reserved")
          state[[i]][units] <- "cancelled"
          money <- money+length(units)*num(orders$cancellation_fee_cents[i])
        }
        if (released[i] && a$type=="RETURN") {
          units <- which(state[[i]]=="shipped")
          units <- head(units[order(dispatched[[i]][units],units,decreasing=TRUE)],count)
          state[[i]][units] <- "returned"
          money <- money-length(units)*(num(orders$unit_price_cents[i])+num(orders$return_fee_cents[i]))
          if (flag(events$restock[j])) {
            st <- order_stock[i]
            stock[st] <- stock[st]+length(units)
            money <- money+length(units)*num(orders$unit_cost_cents[i])
          }
        }
      }
    }
    # Reallocate only free stock after each action. Existing reservations remain sticky.
    for (i in queue[released[queue]]) {
      st <- order_stock[i]
      units <- head(which(state[[i]]=="waiting"),stock[st])
      state[[i]][units] <- "reserved"
      stock[st] <- stock[st]-length(units)
    }
  }
  unfilled <- vapply(state,function(x) sum(x %in% c("waiting","reserved")),integer(1))
  retained <- vapply(state,function(x) sum(x=="shipped"),integer(1))
  count <- lookup(sum_by(retained,orders$customer_id),terms$customer_id)
  rebate <- sum(count*num(terms$rebate_per_unit_cents)*(count>=num(terms$rebate_threshold_units)))
  money-sum(unfilled[released]*num(orders$unfilled_penalty_cents[released]))-rebate
}
