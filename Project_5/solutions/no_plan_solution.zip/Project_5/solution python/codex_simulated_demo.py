"""Generate a small synthetic dataset and run the real calculation engines."""
from decimal import Decimal
import csv
from pathlib import Path
from random import Random
from tempfile import TemporaryDirectory

from codex_data import Dataset
from codex_metrics import Metrics
from codex_scenarios import optimum, replay


class SimulatedData:
    def __init__(self, seed):
        rng = Random(seed)
        price = rng.randint(60, 100)
        self.expected_revenue = Decimal(2 * price - 15)
        self.rows = {}

        def add(name, **fields):
            self.rows.setdefault(name, []).append({k: str(v) for k, v in fields.items()})

        add('accounts', account_id='A', is_test_account=0)
        add('customers', customer_id='C', account_id='A', email='demo@example.org',
            is_test_customer=0, signup_date='2024-01-01', country='Germany')
        add('orders', order_id='O', customer_id='C', order_date='2024-11-01',
            order_status='completed', payment_status='paid', fraud_flag=0,
            is_duplicate=0, currency='EUR', order_level_discount_native=5)
        for payment in ('P1', 'P2'):
            add('payments', payment_id=payment, order_id='O', payment_date='2024-11-01',
                payment_status_detail='settled')
        add('products', product_id='SKU', standard_cost=20, cost_currency='EUR')
        add('product_category_history', product_id='SKU', category='Demo',
            valid_from='2024-01-01', valid_to='2025-01-01')
        add('order_items', order_item_id='L', order_id='O', product_id='SKU',
            quantity=2, unit_price_native=price, line_discount_native=4)
        add('refunds', refund_id='R', order_id='O', product_id='SKU', refund_date='2024-12-01',
            currency='USD', refund_amount_native=8, refund_status='approved')
        add('fx_rates', month='2024-12', currency='USD', eur_rate='0.75')

        def opt(name, **fields):
            add('hard_opt_' + name, case_id='OPT', **fields)

        opt('stock', warehouse_region='W', product_id='SKU', available_units=4)
        opt('dispatch', warehouse_region='W', dispatch_day=1, capacity_units=4)
        opt('suppliers', supplier_id='S', lead_days=1, active=1,
            minimum_units=4, maximum_units=4, activation_cost_cents=7)
        for job in ('J1', 'J2'):
            opt('jobs', job_id=job, product_id='SKU', quantity=2, ready_day=1, due_day=1,
                last_day=2, late_penalty_cents_per_unit_day=2, unfilled_penalty_cents=100)
            opt('options', job_id=job, warehouse_region='W', supplier_id='S',
                dispatch_day=1, variable_cost_cents=10)
        opt('changes', table_name='dispatch', warehouse_region='W', dispatch_day=1,
            field='capacity_units', new_value=2)

        def flow(name, **fields):
            add('flow_' + name, case_id='FLOW', **fields)

        flow('cases', horizon_step=2, knowledge_cutoff_step=0, first_action='SHIFT',
             first_event_id='cancel', first_value=1, second_action='')
        flow('stock', warehouse='W', product_id='SKU', opening_units=0)
        flow('contracts', customer_id='C', version_id='v1', recorded_step=0, status='inactive',
             priority=99, rebate_threshold_units=0, rebate_per_unit_cents=0)
        flow('orders', order_id='O', warehouse='W', product_id='SKU', customer_id='C',
             release_step=1, deadline_step=2, units=2, unit_price_cents=100, unit_cost_cents=30,
             late_penalty_cents=10, unfilled_penalty_cents=20, cancellation_fee_cents=5, return_fee_cents=3)
        # Insert events out of order so the test depends on the engine's action ordering.
        for event, kind, units in [('dispatch','DISPATCH',2), ('receipt','RECEIPT',2), ('cancel','CANCEL',1)]:
            flow('events', event_id=event, event_type=kind, units=units, recorded_step=0,
                 effective_step=2, version_id='v1', status='posted', warehouse='W',
                 product_id='SKU', order_id='O', restock=0)

    def write(self, package):
        folder = Path(package) / 'datasets'
        folder.mkdir()
        for name, rows in self.rows.items():
            with (folder / f'{name}.csv').open('w', encoding='utf-8', newline='') as stream:
                writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)


def test_run(package, expected_revenue):
    data = Dataset(package)
    business = Metrics(data)
    trace = business.revenue_trace('Germany', 4)
    assert trace['orders'] == trace['items'] == 1
    assert trace['net'] == expected_revenue
    # Two jobs cost 10 + 4 cents each, plus one 7-cent supplier activation.
    assert (optimum(data, 'OPT', False), optimum(data, 'OPT', True)) == (35, 200)
    # A cancellation at the dispatch step leaves one sale (70) and one fee (5).
    assert (replay(data, 'FLOW', False), replay(data, 'FLOW', True)) == (75, 140)
    print(f"PASS: revenue EUR {trace['net']:.2f}, optimization 35 / 200 cents, replay 75 / 140 cents")


if __name__ == '__main__':
    simulated = SimulatedData(seed=5)
    with TemporaryDirectory(prefix='codex_simulated_') as package:
        simulated.write(package)
        test_run(package, simulated.expected_revenue)
