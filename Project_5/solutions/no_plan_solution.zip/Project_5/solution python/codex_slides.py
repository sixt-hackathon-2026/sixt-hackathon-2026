from pathlib import Path

from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.colors import HexColor
from codex_data import Business, Dataset

OUT = Path('submission/slides.pdf')
OUT.parent.mkdir(exist_ok=True)
pdf = Canvas(str(OUT),pagesize=(960,540))
pdf.setTitle('Project 5 | From Orders to Verified Answers')
pdf.setAuthor('Project 5 team | Codex-assisted')
ink, orange, muted = map(HexColor,('#171A1D','#C43E0A','#515964'))

def line(x,y,value,size=24,color=ink,bold=False):
    font = 'Helvetica-Bold' if bold else 'Helvetica'
    assert pdf.stringWidth(value,font,size) <= 960-x-44, value
    pdf.setFillColor(color)
    pdf.setFont(font,size)
    pdf.drawString(x,y,value)

def page(title,subtitle):
    line(52,485,'SIXT + TUM   /   PROJECT 5',14,orange,True)
    line(52,418,title,39,ink,True)
    line(52,377,subtitle,21,muted)

def finish():
    pdf.showPage()

page('From Orders to Verified Answers','Stage 1 · Dataset version 7.0.0')
for y,title,detail in [
    (300,'150 business metrics','Orders, procurement, inventory, and returns'),
    (220,'30 cost optimization questions','Exact allocation subject to inventory and capacity constraints'),
    (140,'20 simulation questions','Fulfilment events and what-if scenarios in chronological order'),
]:
    line(52,y,title,25,ink,True)
    line(52,y-29,detail,18,muted)
finish()

page('E001 · Net Revenue in Germany','Q4 2024 · 83 orders and 246 line items')
for y,title,detail in [
    (304,'orders + customers + accounts','Use the customer linked to the order and exclude test records.'),
    (225,'payments + order_items','A settled payment qualifies the order once, keeping each line unique.'),
    (146,'refunds + fx_rates','Group refunds by order and product. Use FX from each refund month.'),
]:
    line(52,y,title,24,ink,True)
    line(52,y-29,detail,18,muted)
finish()

page('EUR 333,368.46','Subtotals in EUR · Round the final result')
for y,label,value in [
    (316,'Gross revenue','354,799.23589036'),
    (269,'Line discounts','−14,467.42794512'),
    (222,'Order discounts','−2,833.19661198'),
    (175,'Approved refunds','−4,130.14694821'),
]:
    line(52,y,label,23)
    line(530,y,value,23,ink,True)
line(52,88,'python codex_data.py',20,orange,True)
finish()

page('Reproducing the Results','200 answers · Official format check passed')
for y,title,detail in [
    (304,'All 10 worked examples match','Tests cover join counts, cutoff dates, FX, and rounding.'),
    (225,'Two scenarios with hand-calculated results','Tests check supplier activation and the order of simultaneous events.'),
    (146,'Codex assisted with design and implementation','Python calculates locally. The final stage uses a separate dataset.'),
]:
    line(52,y,title,24,ink,True)
    line(52,y-29,detail,18,muted)
finish()
final_package = Path(__file__).resolve().parents[1] / 'problem7_student_final'
if final_package.is_dir():
    trace = Business(Dataset(final_package)).revenue_trace('France', 3)
    page('F004 · Net Revenue in France',
         f"Q3 2024 · {trace['orders']} orders and {trace['items']} line items")
    for y, label, field in [(310,'Gross revenue','gross'),(266,'Line discounts','line_discount'),
                            (222,'Order discounts','discount'),(178,'Approved refunds','refund')]:
        line(52,y,label,22)
        line(520,y,f'{trace[field]:,.8f}',22,ink,True)
    line(52,88,f"Net revenue: EUR {trace['net']:,.2f}",24,orange,True)
    finish()
pdf.save()
