# Instruction manual

## 1. Open the project

In PowerShell, start in `Project_5` and enter `Set-Location -LiteralPath 'solution python'`. Use Python 3.12. The competition packages should be in the sibling folders `problem7_student_start` and `problem7_student_final`.

## 2. Check the worked example and the tests

```powershell
python -B codex_data.py
python -B codex_solve.py --check-examples
python -B codex_validate.py
```

The first command prints the components of E001's net revenue. The next two check the ten supplied examples and the targeted regression tests.

## 3. Recalculate the competition answers

```powershell
python -B codex_solve.py --output codex_public_reproduced.csv
python -B codex_solve.py --package ../problem7_student_final --questions final_questions.csv --output codex_final_reproduced.csv
python -B ../problem7_student_final/check_submission.py --questions ../problem7_student_final/final_questions.csv --submission codex_final_reproduced.csv
```

The final loader applies the included column mapping automatically. Final optimization can take longer in pure Python. To use the optional compiled exact search on Windows, follow the build command in [README.md](README.md) and set `$env:CODEX_INTEGER_SEARCH = (Resolve-Path codex_integer_search.exe).Path` before the final run. The commands above write separate output files for comparison.

## 4. Run the synthetic demo

```powershell
python -B codex_simulated_demo.py
```

The script generates a miniature dataset in a temporary directory, loads it through the normal CSV reader, and checks the revenue, optimization, and event replay engines. The expected line starts with `PASS: revenue EUR 183.00`. Both optimization results are 35 and 200 cents. Both replay results are 75 and 140 cents.

To keep the generated CSVs for inspection, start `python` from this folder and run:

```python
from tempfile import mkdtemp
from codex_simulated_demo import SimulatedData, test_run

package = mkdtemp(prefix="codex_simulated_")
demo = SimulatedData(seed=5)
demo.write(package)
test_run(package, demo.expected_revenue)
print(package)
```

Open the printed folder and inspect its `datasets` subfolder. Change the seed to generate a different unit price. The test uses the corresponding expected revenue. The miniature dataset exercises three calculation engines directly.
