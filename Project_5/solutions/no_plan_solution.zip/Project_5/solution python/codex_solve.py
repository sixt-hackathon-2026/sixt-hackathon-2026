import argparse
import csv
import re
import sys
from decimal import Decimal
from pathlib import Path

from codex_data import DEFAULT_PACKAGE, Dataset, read
from codex_operations import Operations

def answer(business, row):
    q = row['question']
    number = int(re.search(r'\d+$',row['question_id'])[0])
    if number <= 100 and not row['question_id'].startswith('E'):
        return business.legacy(q)
    if number <= 150:
        try:
            return business.operation(q)
        except LookupError:
            return business.legacy(q)
    from codex_scenarios import scenario
    return scenario(business.data,q)

def formatted(value, kind):
    if value is None:
        return 'N/A'
    if isinstance(value,bool):
        return str(value).lower()
    if kind == 'integer':
        if value != int(value):
            raise ValueError(f'Nonintegral count: {value}')
        return str(int(value))
    if kind == 'number':
        result = f'{value:.2f}'
        return '0.00' if result == '-0.00' else result
    return str(value)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--package',type=Path,default=DEFAULT_PACKAGE)
    parser.add_argument('--questions',default='public_leaderboard_questions.csv')
    parser.add_argument('--aliases')
    parser.add_argument('--output',type=Path)
    parser.add_argument('--through',type=int,default=200)
    parser.add_argument('--check-examples',action='store_true')
    parser.add_argument('--only')
    args = parser.parse_args()
    if args.output and args.output.name == 'public_answers.csv' and (
        args.questions != 'public_leaderboard_questions.csv' or args.check_examples or args.only
    ):
        parser.error('Use a separate output for final questions, examples or a single question.')
    business = Operations(Dataset(args.package,args.aliases))
    rows = read(args.package / ('solved_examples.csv' if args.check_examples else args.questions))
    results = []
    failed = 0
    for row in rows:
        key = row['question_id']
        if args.only and key != args.only:
            continue
        result = ''
        if int(re.search(r'\d+$',key)[0]) <= args.through:
            try:
                result = formatted(answer(business,row),row['answer_type'])
            except Exception as exc:
                failed += 1
                print(f'{key}: {type(exc).__name__}: {exc}',file=sys.stderr)
        results.append((key,result))
        if args.check_examples:
            expected = row['answer']
            if row['answer_type']=='number' and result not in ('','N/A'):
                match = abs(Decimal(result)-Decimal(expected)) <= Decimal('0.01')
            else:
                match = result==expected
            print(f'{key}: {result} | expected {expected} | {"OK" if match else "FAIL"}')
            failed += not match
    if args.output:
        tmp = args.output.with_suffix('.tmp')
        with tmp.open('w',encoding='utf-8',newline='') as stream:
            writer = csv.writer(stream)
            writer.writerow(('question_id','answer'))
            writer.writerows(results)
        tmp.replace(args.output)
        print(f'{args.output}: {sum(bool(value) for _,value in results)}/{len(results)} answered')
    elif not args.check_examples:
        for key,value in results:
            print(f'{key}: {value}')
    return int(bool(failed))

if __name__ == '__main__':
    raise SystemExit(main())
