import re
from decimal import Decimal as D
from functools import cached_property

from codex_data import REF, flag, group, index, stamp
from codex_metrics import Metrics, grouped_top, pct, ratio, total

def stock_key(row):
    return row['warehouse_region'], row['product_id']

class Operations(Metrics):
    @cached_property
    def purchases(self):
        suppliers = index(self.data.table('suppliers'), lambda r:r['supplier_id'])
        rows = {}
        for r in self.data.table('purchase_order_lines'):
            supplier = suppliers[r['supplier_id']]
            date = stamp(r['ordered_at'])
            if (r['status'] in {'open','closed'} and date <= REF and not flag(supplier['is_test_supplier'])
                    and stamp(supplier['contract_start']) <= date < stamp(supplier['contract_end'])):
                rows[r['po_line_id']] = dict(r, supplier=supplier, date=date, due=stamp(r['promised_at']),
                    units=int(r['ordered_units']), price=D(r['unit_cost_native']),
                    product=self.products[r['product_id']])
        return rows

    @cached_property
    def receipts(self):
        rows = []
        for r in self.data.table('goods_receipts'):
            line = self.purchases.get(r['po_line_id'])
            date = stamp(r['received_at'])
            if line and r['status']=='posted' and line['date'] <= date <= REF:
                accepted, rejected = int(r['accepted_units']), int(r['rejected_units'])
                rows.append(dict(r, line=line, date=date, accepted=accepted, rejected=rejected,
                                 cost=accepted*line['price']*self.data.fx(date,line['currency'])))
        return rows

    @cached_property
    def stock(self):
        movements = group((r for r in index(self.data.table('inventory_movements'),lambda r:r['movement_id']).values()
                           if r['status']=='posted' and stamp(r['event_at']) <= REF),stock_key)
        policies = index((r for r in self.data.table('stock_policies')
                         if stamp(r['valid_from']) <= REF < stamp(r['valid_to'])),stock_key)
        result = []
        for r in self.data.table('warehouse_inventory'):
            key = stock_key(r)
            ledger = [m for m in movements[key] if stamp(m['event_at'])>stamp(r['last_stocktake_date'])]
            end = int(r['on_hand_units'])+sum(int(m['units_delta']) for m in ledger)
            policy = policies[key]
            below = end < int(policy['reorder_point'])
            product = self.products[r['product_id']]
            result.append(dict(r, end=end, below=below, ledger=ledger,
                               reorder=max(0,int(policy['target_units'])-end) if below else 0,
                               value=end*D(product['standard_cost'])*self.data.fx(REF,product['cost_currency'])))
        return result

    @cached_property
    def inspections(self):
        rows = []
        for r in self.data.table('return_inspections'):
            refund = self.refunds.get(r['refund_id'])
            if refund and r['status']=='completed' and refund['date'] <= stamp(r['inspected_at']) <= REF:
                restockable = int(r['restockable_units'])
                rows.append(dict(r, refund=refund, category=self.pair_category[refund['pair']],
                                 restockable=restockable, received=int(r['units_received']),
                                 recovery=restockable*D(r['recovery_unit_value_eur'])))
        return rows

    @cached_property
    def worklogs(self):
        tickets = index(self.tickets,lambda r:r['ticket_id'])
        rows = []
        for r in self.data.table('support_worklogs'):
            t = tickets.get(r['ticket_id'])
            date = stamp(r['worked_at'])
            if t and r['work_status']=='approved' and t['date'] <= date <= REF:
                minutes = int(r['minutes_worked'])
                labor = D(minutes)*D(r['hourly_rate_native'])*self.data.fx(date,r['currency'])/60
                rows.append(dict(r, ticket=t, minutes=minutes, date=date, labor=labor))
        return rows

    @cached_property
    def contracts(self):
        versions = group((r for r in self.data.table('account_contract_versions')
                          if stamp(r['recorded_at'])<=REF), lambda r:r['contract_id'])
        latest = [max(g,key=lambda r:(stamp(r['recorded_at']),int(r['revision']))) for g in versions.values()]
        return group((r for r in latest if r['status']=='active' and r['account_id'] in self.accounts),
                     lambda r:r['account_id'])

    def contract(self, account, date):
        matches = [r for r in self.contracts[account] if stamp(r['valid_from']) <= date < stamp(r['valid_to'])]
        if len(matches)>1:
            raise ValueError(f'Overlapping contracts for {account}')
        return next(iter(matches),None)

    def operation(self,q):
        if m := re.search(r'(?:For|Among) accounts in the (.+?) segment,',q):
            accounts = {a for a,r in self.accounts.items() if r['segment']==m[1]}
            tickets = [t for t in self.tickets if t['customer']['account_id'] in accounts]
            covered = [(t,self.contract(t['customer']['account_id'],t['date'])) for t in tickets]
            credits = sum(D(c['service_credit_eur']) for t,c in covered if c and t['breach'])
            logs = [w for w in self.worklogs if w['ticket']['customer']['account_id'] in accounts]
            if 'coverage' in q or 'percentage' in q:
                return pct(sum(c is not None for _,c in covered),len(tickets))
            if 'adjusted margin' in q:
                margin = total((r for r in self.items if r['order']['customer']['account_id'] in accounts),'margin')
                return margin-total(logs,'labor')-credits
            if 'total service cost' in q:
                return total(logs,'labor')+credits
            if 'service credit' in q:
                return credits
            if 'run-rate' in q:
                return sum(D(c['quarterly_fee_eur']) for a in accounts if (c := self.contract(a,REF)))
            if 'overage' in q:
                by_account = group((w for w in logs if '2024-10-01'<=w['date']<'2025-01-01'),
                                   lambda w:w['ticket']['customer']['account_id'])
                return sum(max(0,total(by_account[a],'minutes')-int(c['included_support_minutes']))
                           for a in accounts if (c := self.contract(a,'2024-10-01T00:00:00')))
        if m := re.search(r'For support channel (.+?),',q):
            return ratio(sum(w['minutes'] for w in self.worklogs if w['ticket']['support_channel']==m[1]
                             and flag(w['is_billable'])),60)
        if m := re.search(r'For (?:customers in )?(.+?), which (?:support )?issue type',q):
            tickets = [t for t in self.tickets if t['customer']['country']==m[1]]
            logs = group(self.worklogs,lambda w:w['ticket_id'])
            return grouped_top(tickets,lambda t:t['issue_type'],
                               lambda g:ratio(sum(total(logs[t['ticket_id']],'labor') for t in g),len(g)))
        if m := re.search(r'For support issue (.+?),',q):
            rows = [r for r in self.worklogs if r['ticket']['issue_type']==m[1]]
            if 'labor cost' in q:
                return total(rows,'labor')
            if 'no eligible worklog' in q:
                return sum(r['issue_type']==m[1] and r['ticket_id'] not in {w['ticket_id'] for w in rows} for r in self.tickets)
        if m := re.search(r'For refund reason (.+?),',q):
            rows = [r for r in self.inspections if r['refund']['refund_reason']==m[1]]
            if 'restockable' in q:
                return pct(total(rows,'restockable'),total(rows,'received'))
            if 'no eligible inspection' in q:
                inspected = {r['refund_id'] for r in rows}
                return sum(r['refund_reason']==m[1] and rid not in inspected for rid,r in self.refunds.items())
        if m := re.search(r'For original order-time category (.+?),',q):
            if 'adjusted' in q:
                gross = total((r for r in self.items if r['category']==m[1]),'gross')
                refund = total((r for r in self.refunds.values() if self.pair_category[r['pair']]==m[1]),'eur')
                recovery = total((r for r in self.inspections if r['category']==m[1]),'recovery')
                return pct(refund-recovery,gross)
            return total((r for r in self.inspections if r['category']==m[1]),'recovery')
        if m := re.search(r'(?:For|In) warehouse (.+?),',q):
            warehouse = m[1]
            if 'cost of accepted units' in q:
                return total((r for r in self.receipts if r['line']['warehouse_region']==warehouse),'cost')
            if 'units remain outstanding' in q:
                receipts = group(self.receipts,lambda r:r['po_line_id'])
                return sum(max(0,r['units']-total(receipts[k],'accepted')) for k,r in self.purchases.items()
                           if r['warehouse_region']==warehouse)
            rows = [r for r in self.stock if r['warehouse_region']==warehouse]
            for phrase, field in [('total reconciled stock','end'),('value of reconciled stock','value'),
                                  ('strictly below the reorder point','below'),('replenishment units','reorder')]:
                if phrase in q:
                    return total(rows,field)
            if 'adjustment' in q:
                return sum(int(m['units_delta']) for r in rows for m in r['ledger'] if m['movement_type']=='adjustment')
            if 'coverage days' in q:
                demand = -sum(int(m['units_delta']) for r in rows for m in r['ledger']
                              if m['movement_type']=='sale_issue' and '2024-10-01'<=stamp(m['event_at'])<'2025-01-01')
                return ratio(92*total(rows,'end'),demand)
        if m := re.search(r'(?:For suppliers|Among eligible suppliers) in (.+?)(?:,| with)',q):
            country = m[1]
            lines = [r for r in self.purchases.values() if r['supplier']['country']==country]
            rows = [r for r in self.receipts if r['line']['supplier']['country']==country]
            rejection = lambda g:pct(total(g,'rejected'),total(g,'accepted')+total(g,'rejected'))
            if 'purchase commitment' in q:
                return sum(r['units']*r['price']*self.data.fx(r['date'],r['currency']) for r in lines)
            if 'accepted on time' in q:
                due = [r for r in lines if r['due']<=REF]
                receipts = group((r for r in rows if r['date']<=r['line']['due']),lambda r:r['po_line_id'])
                return pct(sum(min(r['units'],total(receipts[r['po_line_id']],'accepted')) for r in due),total(due,'units'))
            if 'rejected-unit percentage' in q:
                return rejection(rows)
            if 'highest rejected/' in q:
                return grouped_top(rows,lambda r:r['line']['supplier']['supplier_name'],rejection)
            if 'shortfall' in q:
                receipts = group(rows,lambda r:r['po_line_id'])
                return sum(max(0,r['units']-total(receipts[r['po_line_id']],'accepted'))*r['price']
                           *self.data.fx(r['date'],r['currency']) for r in lines if r['due']<=REF)
            if 'count' in q or 'how many' in q:
                return len(rows)
        if m := re.search(r'For product family (.+?),',q):
            family = m[1]
            def matches(line):
                return family=='All families' or line['product']['family']==family
            if 'purchase price variance' in q:
                return sum(r['units']*(r['price']*self.data.fx(r['date'],r['currency'])
                           - D(r['product']['standard_cost'])*self.data.fx(r['date'],r['product']['cost_currency']))
                           for r in self.purchases.values() if matches(r))
            if 'supplier' in q:
                return grouped_top((r for r in self.receipts if matches(r['line'])),
                                   lambda r:r['line']['supplier']['supplier_name'],lambda g:total(g,'accepted'))
        raise LookupError('Unmapped operations question')
