import re
import os
import subprocess
from collections import Counter, defaultdict
from decimal import Decimal
from functools import cache

from codex_data import flag, index

def case_rows(data, table, case):
    return [dict(r) for r in data.table(table) if r['case_id']==case]

@cache
def optimum(data, case, changed):
    keys = {
        'stock': lambda r:(r['warehouse_region'],r['product_id']),
        'dispatch': lambda r:(r['warehouse_region'],r['dispatch_day']),
        'suppliers': lambda r:r['supplier_id'],
    }
    tables = {name:index(case_rows(data,'hard_opt_'+name,case),key) for name,key in keys.items()}
    if changed:
        # Each run owns its resource rows. Apply all replacements before filtering options.
        for row in case_rows(data,'hard_opt_changes',case):
            name = row['table_name']
            tables[name][keys[name](row)][row['field']] = row['new_value']
    stock = {k:int(r['available_units']) for k,r in tables['stock'].items()}
    dispatch = {k:int(r['capacity_units']) for k,r in tables['dispatch'].items()}
    suppliers = tables['suppliers']
    jobs = index(case_rows(data,'hard_opt_jobs',case),lambda r:r['job_id'])
    feasible = defaultdict(list)
    for r in case_rows(data,'hard_opt_options',case):
        job, supplier = jobs[r['job_id']], suppliers[r['supplier_id']]
        day, qty = int(r['dispatch_day']), int(job['quantity'])
        arrival = day + int(supplier['lead_days'])
        sk = r['warehouse_region'], job['product_id']
        dk = r['warehouse_region'], r['dispatch_day']
        if (flag(supplier['active']) and day>=int(job['ready_day']) and arrival<=int(job['last_day'])
                and stock.get(sk,0)>=qty and dispatch.get(dk,0)>=qty and int(supplier['maximum_units'])>=qty):
            cost = int(r['variable_cost_cents'])+qty*int(job['late_penalty_cents_per_unit_day'])*max(0,arrival-int(job['due_day']))
            feasible[r['job_id']].append((cost,sk,dk,r['supplier_id']))
    # Search exact integer choices. The suffix bound ignores coupling and activation costs.
    rows = []
    for key,j in jobs.items():
        penalty = int(j['unfilled_penalty_cents'])
        choices = sorted(feasible[key]+[(penalty,None,None,None)],key=lambda x:x[0])
        rows.append((int(j['quantity']),choices))
    rows.sort(key=lambda r:(-(r[1][-1][0]-r[1][0][0]),len(r[1])))
    if executable := os.environ.get('CODEX_INTEGER_SEARCH'):
        # Optional compiled implementation of the same search for larger cases.
        stock_ids = {key:i for i,key in enumerate(stock)}
        dispatch_ids = {key:i for i,key in enumerate(dispatch)}
        supplier_ids = {key:i for i,key in enumerate(suppliers)}
        def line(values):
            return ' '.join(map(str,values))
        payload = [line([len(rows),len(stock),len(dispatch),len(suppliers)]),
                   line(stock.values()),line(dispatch.values())]
        payload.extend(line(r[key] for key in ('minimum_units','maximum_units','activation_cost_cents'))
                       for r in suppliers.values())
        for qty, choices in rows:
            payload.append(line([qty,len(choices)]))
            for price, sk, dk, sid in choices:
                payload.append(line([price,stock_ids.get(sk,-1),dispatch_ids.get(dk,-1),supplier_ids.get(sid,-1)]))
        result = subprocess.run([executable],input='\n'.join(payload),text=True,capture_output=True,check=True)
        return int(result.stdout)
    suffix = [0]*(len(rows)+1)
    reachable = [Counter() for _ in suffix]
    for i in reversed(range(len(rows))):
        qty, choices = rows[i]
        suffix[i] = suffix[i+1]+choices[0][0]
        reachable[i] = reachable[i+1].copy()
        for supplier in {r[3] for r in choices if r[3] is not None}:
            reachable[i][supplier] += qty

    best = sum(int(j['unfilled_penalty_cents']) for j in jobs.values())
    used = Counter()
    minimum = {k:int(r['minimum_units']) for k,r in suppliers.items()}
    maximum = {k:int(r['maximum_units']) for k,r in suppliers.items()}
    activation = {k:int(r['activation_cost_cents']) for k,r in suppliers.items()}
    negative_fees = {k:v for k,v in activation.items() if v<0}

    def visit(i, cost):
        nonlocal best
        possible_credits = sum(v for s,v in negative_fees.items() if not used[s] and reachable[i][s])
        if cost+suffix[i]+possible_credits>=best:
            return
        if any(used[s] and used[s]+reachable[i][s]<minimum[s] for s in suppliers):
            return
        # Reprice the remaining jobs against residual capacity. This is still a
        # lower bound because each remaining job can independently reuse that capacity.
        bound = cost + possible_credits
        for j in range(i,len(rows)):
            quantity, alternatives = rows[j]
            for price, sk, dk, supplier in alternatives:
                if supplier is None or (stock[sk]>=quantity and dispatch[dk]>=quantity
                                        and used[supplier]+quantity<=maximum[supplier]):
                    bound += price
                    break
            if bound+suffix[j+1]>=best:
                return
        if i==len(rows):
            best = cost
            return
        qty, choices = rows[i]
        for price, sk, dk, supplier in choices:
            if supplier is None:
                visit(i+1,cost+price)
            elif stock[sk]>=qty and dispatch[dk]>=qty and used[supplier]+qty<=maximum[supplier]:
                fee = activation[supplier] if not used[supplier] else 0
                stock[sk] -= qty
                dispatch[dk] -= qty
                used[supplier] += qty
                visit(i+1,cost+price+fee)
                used[supplier] -= qty
                dispatch[dk] += qty
                stock[sk] += qty

    visit(0,0)
    return best

def known(rows, key, cutoff):
    result = {}
    for r in rows:
        precedence = int(r['recorded_step']),r['version_id']
        if precedence[0]<=cutoff and (r[key] not in result or precedence>result[r[key]][0]):
            result[r[key]] = precedence,r
    return {k:r for k,(_,r) in result.items()}

@cache
def replay(data, case, changed):
    config, = case_rows(data,'flow_cases',case)
    cutoff, horizon = int(config['knowledge_cutoff_step']),int(config['horizon_step'])
    events = known(case_rows(data,'flow_events',case),'event_id',cutoff)
    terms = {k:r for k,r in known(case_rows(data,'flow_contracts',case),'customer_id',cutoff).items()
             if r['status']=='active'}
    if changed:
        # Edit the known versions before applying the horizon or sorting the actions.
        for prefix in ('first','second'):
            action = config[prefix+'_action']
            if action:
                event = events[config[prefix+'_event_id']]
                value = int(config[prefix+'_value'])
                if action=='SHIFT':
                    event['effective_step'] = int(event['effective_step'])+value
                elif action=='SET_UNITS':
                    event['units'] = value
                else:
                    raise ValueError(action)

    def key(row):
        return row['warehouse'],row['product_id']

    stock = Counter({key(r):int(r['opening_units']) for r in case_rows(data,'flow_stock',case)})
    orders = index(case_rows(data,'flow_orders',case),lambda r:r['order_id'])
    # List position is the unit sequence. Store dispatch order for last-shipped-first returns.
    sequence = {oid:[['waiting',None] for _ in range(int(r['units']))] for oid,r in orders.items()}
    priority = {a:i for i,a in enumerate(('CANCEL','RETURN','RECEIPT','RELEASE','DISPATCH'))}
    actions = [(int(r['effective_step']),priority[r['event_type']],eid,r['event_type'],r)
               for eid,r in events.items() if r['status']!='void']
    actions += [(int(r['release_step']),priority['RELEASE'],oid,'RELEASE',r) for oid,r in orders.items()]
    queue = sorted(orders,key=lambda oid:(int(terms.get(orders[oid]['customer_id'],{}).get('priority',99)),
                       int(orders[oid]['deadline_step']),int(orders[oid]['release_step']),oid))
    released = set()
    contribution = 0
    for action_number, (step,_,_,action,r) in enumerate(sorted(actions)):
        if step>horizon:
            break
        units = int(r['units'])
        if action=='RELEASE':
            released.add(r['order_id'])
        elif action=='RECEIPT':
            stock[key(r)] += units
        elif action=='DISPATCH':
            for oid in queue:
                order = orders[oid]
                if order['warehouse']!=r['warehouse'] or oid not in released:
                    continue
                for unit in sequence[oid]:
                    if units and unit[0]=='reserved':
                        unit[:] = ['shipped',action_number]
                        units -= 1
                        contribution += int(order['unit_price_cents'])-int(order['unit_cost_cents'])
                        if step>int(order['deadline_step']):
                            contribution -= int(order['late_penalty_cents'])
        elif r['order_id'] in released:
            oid = r['order_id']
            order = orders[oid]
            if action=='CANCEL':
                available = [u for u in sequence[oid] if u[0] in {'waiting','reserved'}]
                for unit in available[:units]:
                    stock[key(order)] += unit[0]=='reserved'
                    unit[0] = 'cancelled'
                    contribution += int(order['cancellation_fee_cents'])
            elif action=='RETURN':
                shipped = sorted((i for i,u in enumerate(sequence[oid]) if u[0]=='shipped'),
                                 key=lambda i:(sequence[oid][i][1],i),reverse=True)
                for i in shipped[:units]:
                    sequence[oid][i][0] = 'returned'
                    contribution -= int(order['unit_price_cents'])+int(order['return_fee_cents'])
                    if flag(r['restock']):
                        stock[key(order)] += 1
                        contribution += int(order['unit_cost_cents'])

        # Allocate free stock after each action. Existing reservations stay in place.
        for oid in queue:
            if oid not in released:
                continue
            stock_key = key(orders[oid])
            for unit in sequence[oid]:
                if stock[stock_key] and unit[0]=='waiting':
                    stock[stock_key] -= 1
                    unit[0] = 'reserved'

    retained = Counter()
    for oid in released:
        order = orders[oid]
        for state,_ in sequence[oid]:
            if state in {'waiting','reserved'}:
                contribution -= int(order['unfilled_penalty_cents'])
            elif state=='shipped':
                retained[order['customer_id']] += 1
    for customer, units in retained.items():
        term = terms.get(customer)
        if term and units>=int(term['rebate_threshold_units']):
            contribution -= units*int(term['rebate_per_unit_cents'])
    return contribution

def scenario(data,q):
    match = re.search(r'(?:decision )?case ([A-Za-z0-9_]+),',q)
    if not match:
        raise LookupError('Unmapped scenario question')
    case = match[1]
    if case in {r['case_id'] for r in data.table('hard_opt_cases')}:
        engine = optimum
    elif case in {r['case_id'] for r in data.table('flow_cases')}:
        engine = replay
    else:
        raise LookupError(f'Unknown case {case}')
    baseline = engine(data,case,False)
    cents = engine(data,case,True)-baseline if 'change in' in q else baseline
    return Decimal(cents)/100
