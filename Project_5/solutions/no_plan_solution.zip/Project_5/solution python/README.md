# Python solution

This folder contains the Python code, results, and submission materials. The released dataset is in the sibling `problem7_student_start/` directory.

From `Project_5` in PowerShell:

```powershell
Set-Location -LiteralPath 'solution python'
python -B codex_data.py
python -B codex_solve.py --check-examples
python -B codex_validate.py
python -B codex_solve.py --output codex_reproduced.csv
python -B ../problem7_student_start/check_submission.py --questions ../problem7_student_start/public_leaderboard_questions.csv --submission codex_reproduced.csv
```

Python 3.12 and its standard library are sufficient to calculate the answers. To rebuild the slides from this directory, run `python -m pip install -r codex_requirements.txt` and `python -B codex_slides.py`. Official submission files also appear at the designated paths in `Project_5`.

## Stage 2

Run from `solution python` in Windows PowerShell. The optional executable speeds up exact optimization for the 26-job cases. Build it from the included source with the Windows .NET Framework compiler:

```powershell
& "$env:WINDIR/Microsoft.NET/Framework64/v4.0.30319/csc.exe" /nologo /optimize+ /out:codex_integer_search.exe codex_integer_search.cs
$env:CODEX_INTEGER_SEARCH = (Resolve-Path codex_integer_search.exe).Path
python -B codex_solve.py --package ../problem7_student_final --questions final_questions.csv --output codex_final_reproduced.csv
python -B ../problem7_student_final/check_submission.py --questions ../problem7_student_final/final_questions.csv --submission codex_final_reproduced.csv
```

Without `CODEX_INTEGER_SEARCH`, the solver uses the same exact search in Python. It may take substantially longer. The loader automatically applies `codex_final_columns.csv` for the released final package.
