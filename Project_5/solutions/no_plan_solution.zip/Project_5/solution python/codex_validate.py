import unittest
from collections import defaultdict
from decimal import Decimal as D
from types import SimpleNamespace

from codex_data import DEFAULT_PACKAGE, Dataset, REF
from codex_metrics import period, window
from codex_operations import Operations
from codex_scenarios import known, optimum, replay
from codex_solve import formatted

class Checks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = Dataset(DEFAULT_PACKAGE)
        cls.ops = Operations(cls.data)

    def test_payment_existence_and_refund_conservation(self):
        counts = defaultdict(int)
        for p in self.data.table('payments'):
            if p['payment_status_detail']=='settled' and p['payment_date'].replace(' ','T')<=REF:
                counts[p['order_id']] += 1
        multiple = {k for k in self.ops.orders if counts[k]>1}
        self.assertTrue(multiple)
        for key in multiple:
            expected = {r['order_item_id'] for r in self.data.table('order_items') if r['order_id']==key}
            actual = [r['order_item_id'] for r in self.ops.items if r['order_id']==key]
            self.assertCountEqual(actual,expected)
        refunds = defaultdict(D)
        for r in self.ops.refunds.values():
            refunds[r['pair']] += r['eur']
        allocated = defaultdict(D)
        for r in self.ops.items:
            allocated[r['order_id'],r['product_id']] += r['refund']
        self.assertTrue(refunds)
        for key, amount in refunds.items():
            self.assertLess(abs(allocated[key]-amount),D('1e-19'))
        self.assertEqual(set(allocated),set(self.ops.pair_category))

    def test_cutoff_fx_rounding(self):
        self.assertTrue(period('2024-10-01T00:00:00','Q4'))
        self.assertFalse(period(REF,'Q4'))
        self.assertFalse(window('2024-01-01T00:00:00','2024-01-15T00:00:01',14))
        self.assertTrue(window('2024-01-01T00:00:00','2024-01-15T00:00:00',14))
        self.assertEqual(self.data.fx(REF,'EUR'),1)
        with self.assertRaises(KeyError):
            self.data.fx(REF,'UNKNOWN')
        for r in self.ops.refunds.values():
            self.assertLessEqual(r['date'],REF)
            self.assertEqual(r['eur'],D(r['refund_amount_native'])*self.data.fx(r['date'],r['currency']))
        self.assertEqual(formatted(D('10.125'),'number'),'10.12')
        self.assertEqual(formatted(D('10.135'),'number'),'10.14')

    def test_version_tie_and_void(self):
        rows = [dict(event_id='e',recorded_step=n,version_id=v,status=s)
                for n,v,s in [(1,'v9','void'),(1,'v10','posted'),(2,'v1','posted')]]
        self.assertEqual(known(rows,'event_id',1)['e']['status'],'void')
        self.assertEqual(known(reversed(rows),'event_id',1)['e']['status'],'void')

    def test_simultaneous_actions_and_what_if(self):
        c = 'fixture'
        def event(eid,kind,step,units,**fields):
            return dict(dict(case_id=c,event_id=eid,event_type=kind,effective_step=step,units=units,
                             recorded_step=0,version_id='v1',status='posted',warehouse='W',product_id='P',
                             order_id='O',restock='false'),**fields)
        tables = {
            'flow_cases':[dict(case_id=c,horizon_step=2,knowledge_cutoff_step=0,
                               first_action='SHIFT',first_event_id='cancel',first_value=1,second_action='')],
            'flow_contracts':[],
            'flow_stock':[dict(case_id=c,warehouse='W',product_id='P',opening_units=0)],
            'flow_orders':[dict(case_id=c,order_id='O',warehouse='W',product_id='P',customer_id='C',
                                units=2,release_step=1,deadline_step=2,unit_price_cents=100,
                                unit_cost_cents=30,late_penalty_cents=10,unfilled_penalty_cents=20,
                                cancellation_fee_cents=5,return_fee_cents=3)],
            'flow_events':[event('dispatch','DISPATCH',2,2),event('receipt','RECEIPT',2,2),
                           event('cancel','CANCEL',2,1),event('return','RETURN',2,1)],
        }
        class Fixture:
            def table(self,name):
                return tables[name]
        data = Fixture()
        self.assertEqual(replay(data,c,False),75)
        self.assertEqual(replay(data,c,True),140)

    def test_activation_minimum_and_counterfactual(self):
        c = 'fixture'
        def rows(*entries):
            return [dict(r,case_id=c) for r in entries]
        tables = {
            'hard_opt_stock':rows(dict(warehouse_region='W',product_id='P',available_units=4)),
            'hard_opt_dispatch':rows(dict(warehouse_region='W',dispatch_day='0',capacity_units=4)),
            'hard_opt_suppliers':rows(dict(supplier_id='S',lead_days=1,active='1',minimum_units=4,
                                           maximum_units=4,activation_cost_cents=7)),
            'hard_opt_jobs':rows(*(dict(job_id=j,product_id='P',quantity=2,ready_day=0,due_day=0,last_day=1,
                                       late_penalty_cents_per_unit_day=2,unfilled_penalty_cents=100) for j in 'AB')),
            'hard_opt_options':rows(*(dict(job_id=j,warehouse_region='W',supplier_id='S',dispatch_day='0',
                                            variable_cost_cents=10) for j in 'AB')),
            'hard_opt_changes':rows(dict(table_name='dispatch',warehouse_region='W',dispatch_day='0',
                                        field='capacity_units',new_value='2')),
        }
        class Fixture:
            def table(self,name):
                return tables[name]
        data = Fixture()
        self.assertEqual(optimum(data,c,False),35)
        self.assertEqual(optimum(data,c,True),200)

if __name__=='__main__':
    unittest.main()
