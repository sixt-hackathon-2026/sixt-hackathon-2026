import csv
import json
from collections import defaultdict
from datetime import datetime
from decimal import Decimal as D
from functools import cache
from pathlib import Path

REF = '2025-01-01T00:00:00'
DEFAULT_PACKAGE = Path(__file__).resolve().parents[1] / 'problem7_student_start'

def stamp(value):
    return datetime.fromisoformat(value).isoformat() if value else ''

def flag(value):
    return value.lower() in {'true', '1', 'yes'}

def group(rows, key):
    result = defaultdict(list)
    for row in rows:
        result[key(row)].append(row)
    return result

def index(rows, key):
    result = {}
    for row in rows:
        k = key(row)
        if k in result:
            raise ValueError(f'Duplicate key: {k}')
        result[k] = row
    return result

def read(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

class Dataset:
    def __init__(self, package, aliases=None):
        self.package = Path(package)
        self.aliases = {}
        if aliases:
            self.aliases = json.loads(Path(aliases).read_text(encoding='utf-8'))
        elif (self.package / 'final_questions.csv').is_file():
            # Normalize the released final headers once so both stages use the same recipes.
            for row in read(Path(__file__).with_name('codex_final_columns.csv')):
                columns = self.aliases.setdefault(row['table'], {'columns': {}})['columns']
                columns[row['source']] = row['canonical']

    @cache
    def table(self, name):
        config = self.aliases.get(name, {})
        aliases = config.get('columns', {})
        rows = read(self.package / 'datasets' / config.get('file', f'{name}.csv'))
        if rows:
            unknown = aliases.keys() - rows[0].keys()
            if unknown:
                raise ValueError(f'{name}: alias source columns missing: {sorted(unknown)}')
            renamed = [aliases.get(key, key) for key in rows[0]]
            if len(set(renamed)) != len(renamed):
                raise ValueError(f'{name}: aliases create duplicate column names')
        return [{aliases.get(key, key): value for key, value in row.items()} for row in rows]

    @cache
    def rates(self):
        return index(self.table('fx_rates'), lambda r: (r['month'], r['currency']))

    def fx(self, date, currency):
        return D(1) if currency == 'EUR' else D(self.rates()[date[:7], currency]['eur_rate'])

def identity(email):
    local, domain = email.strip().lower().rsplit('@', 1)
    local = local.split('+', 1)[0]
    if domain in {'gmail.com', 'googlemail.com'}:
        local, domain = local.replace('.', ''), 'gmail.com'
    return local + '@' + domain

class Business:
    def __init__(self, data):
        self.data = data
        table = data.table
        self.accounts = {r['account_id']: r for r in table('accounts') if not flag(r['is_test_account'])}
        self.customers = {r['customer_id']: dict(r, identity=identity(r['email']))
                          for r in table('customers')
                          if not flag(r['is_test_customer']) and r['account_id'] in self.accounts}
        self.real = {}
        for r in sorted(self.customers.values(), key=lambda r: (stamp(r['signup_date']), r['customer_id'])):
            if stamp(r['signup_date']) <= REF:
                self.real.setdefault(r['identity'], r)
        payments = {p['order_id'] for p in table('payments')
                    if p['payment_status_detail'] == 'settled' and stamp(p['payment_date']) <= REF}
        self.orders = index((dict(r, date=stamp(r['order_date']), customer=self.customers[r['customer_id']], net=D(0))
                             for r in table('orders')
                             if r['order_id'] in payments and r['customer_id'] in self.customers
                             and stamp(r['order_date']) <= REF and r['order_status'] in {'completed', 'shipped'}
                             and r['payment_status'] == 'paid' and not flag(r['fraud_flag'])
                             and not flag(r['is_duplicate'])), lambda r: r['order_id'])
        lines = group((r for r in table('order_items') if r['order_id'] in self.orders), lambda r: r['order_id'])
        self.products = index(table('products'), lambda r: r['product_id'])
        history = group(table('product_category_history'), lambda r: r['product_id'])
        pairs = {(r['order_id'], r['product_id']) for rows in lines.values() for r in rows}
        self.refunds = {}
        refunds_by_pair = defaultdict(D)
        for r in table('refunds'):
            pair = r['order_id'], r['product_id']
            date = stamp(r['refund_date'])
            if pair in pairs and r['refund_status'] == 'approved' and date <= REF:
                eur = D(r['refund_amount_native']) * data.fx(date, r['currency'])
                self.refunds[r['refund_id']] = dict(r, eur=eur, date=date, pair=pair)
                refunds_by_pair[pair] += eur

        self.items = []
        self.pair_category = {}
        for order_id, rows in lines.items():
            order = self.orders[order_id]
            date = order['date']
            fx = data.fx(date, order['currency'])
            gross = [D(r['quantity']) * D(r['unit_price_native']) for r in rows]
            pre = [g - D(r['line_discount_native']) for g, r in zip(gross, rows)]
            total_pre = sum(pre)
            product_weight, product_count = defaultdict(D), defaultdict(int)
            for r, amount in zip(rows, pre):
                product_weight[r['product_id']] += max(amount, 0)
                product_count[r['product_id']] += 1
            for r, g, amount in zip(rows, gross, pre):
                pid = r['product_id']
                product = self.products[pid]
                category, = (h['category'] for h in history[pid]
                             if stamp(h['valid_from']) <= date <= stamp(h['valid_to']))
                pair = order_id, pid
                self.pair_category[pair] = category
                weight = product_weight[pid]
                refund_share = max(amount, 0) / weight if weight else D(1) / product_count[pid]
                refund = refunds_by_pair[pair] * refund_share
                discount = D(order['order_level_discount_native']) * amount / total_pre * fx if total_pre else D(0)
                net = amount * fx - discount - refund
                cost = D(r['quantity']) * D(product['standard_cost']) * data.fx(date, product['cost_currency'])
                order['net'] += net
                self.items.append(dict(r, order=order, category=category, product=product,
                                       gross=g*fx, line_discount=(g-amount)*fx, discount=discount,
                                       refund=refund, net=net, margin=net-cost))

    def revenue_trace(self, country, quarter):
        start, end = quarter_bounds(quarter)
        rows = [r for r in self.items if r['order']['customer']['country'] == country
                and start <= r['order']['date'] < end]
        return {'orders': len({r['order_id'] for r in rows}), 'items': len(rows),
                **{key: sum(r[key] for r in rows) for key in ('gross', 'line_discount', 'discount', 'refund', 'net')}}

def quarter_bounds(quarter):
    start = 3 * (int(quarter) - 1) + 1
    return f'2024-{start:02}-01', f'2024-{start+3:02}-01' if start < 10 else '2025-01-01'

if __name__ == '__main__':
    trace = Business(Dataset(DEFAULT_PACKAGE)).revenue_trace('Germany', 4)
    for key, value in trace.items():
        print(f'{key}: {value}')
    print(f"E001: {trace['net']:.2f}")
