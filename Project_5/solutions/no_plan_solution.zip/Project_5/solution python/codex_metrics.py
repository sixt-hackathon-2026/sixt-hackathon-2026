import re
from datetime import datetime, timedelta
from decimal import Decimal as D
from functools import cached_property
from statistics import correlation, median, mean, pstdev

from codex_data import Business, REF, flag, group, index, quarter_bounds, stamp

def total(rows, field='net'):
    return sum(r[field] for r in rows)

def ratio(a, b):
    return a / b if b else None

def pct(a, b):
    return ratio(100*a, b)

def window(a, b, days):
    return bool(a and b) and timedelta(0) <= datetime.fromisoformat(b)-datetime.fromisoformat(a) <= timedelta(days=days)

def period(date, value):
    if value.startswith('Q'):
        start, end = quarter_bounds(value[1])
        return start <= date < end
    return date.startswith(value)

def rank(scores):
    return sorted((key for key in scores if scores[key] is not None), key=lambda k: (-scores[k], k))

def top(scores):
    return next(iter(rank(scores)), None)

def grouped_top(rows, key, score):
    return top({k: score(g) for k, g in group(rows, key).items()})

class Metrics(Business):
    @cached_property
    def by_person(self):
        return group(sorted(self.orders.values(), key=lambda r: (r['date'],r['order_id'])),
                     lambda r:r['customer']['identity'])

    @cached_property
    def by_account(self):
        return group(self.orders.values(), lambda r:r['customer']['account_id'])

    @cached_property
    def tickets(self):
        tickets = []
        for r in self.data.table('support_tickets'):
            opened, resolved = stamp(r['opened_at']), stamp(r['resolved_at'])
            if r['customer_id'] not in self.customers or opened > REF:
                continue
            known = bool(resolved and resolved <= REF)
            hours = (datetime.fromisoformat(resolved if known else REF)-datetime.fromisoformat(opened)).total_seconds()/3600
            limit = {'urgent':24, 'high':48, 'medium':72, 'low':120}[r['priority']]
            tickets.append(dict(r, customer=self.customers[r['customer_id']], date=opened, breach=hours>limit, unresolved=not known))
        return tickets

    @cached_property
    def late(self):
        late = []
        for r in self.data.table('shipments'):
            order = self.orders.get(r['order_id'])
            if order is None or stamp(r['shipped_at']) > REF:
                continue
            delivered = stamp(r['delivered_at'])
            known = delivered if delivered and delivered <= REF else ''
            promised = stamp(r['promised_delivery_date'])
            delay = (datetime.fromisoformat(known or REF).date()-datetime.fromisoformat(promised).date()).days
            if delay > 0 and promised < REF:
                late.append(dict(r, order=order, delivered=known, delay=delay, net=order['net']))
        return late

    @cached_property
    def touches(self):
        return [dict(r, person=self.customers[r['customer_id']]['identity'], date=stamp(r['touch_date']))
                for r in self.data.table('marketing_touches')
                if r['customer_id'] in self.customers and stamp(r['touch_date']) <= REF]

    @cached_property
    def attributed(self):
        touches = group(self.touches, lambda r:r['person'])
        result = []
        for person, orders in self.by_person.items():
            for order in orders:
                candidates = [r for r in touches[person] if window(r['date'],order['date'],30)]
                if candidates:
                    date = max(r['date'] for r in candidates)
                    best = min((r for r in candidates if r['date']==date), key=lambda r:(r['campaign'],r['touch_id']))
                    result.append(dict(best, net=order['net'], order=order))
        return result

    @cached_property
    def at_risk(self):
        unresolved = {r['customer']['identity'] for r in self.tickets if r['unresolved']}
        cutoff = (datetime.fromisoformat(REF)-timedelta(days=75)).isoformat()
        return [dict(r, net=total(self.by_person[p]), manager=self.accounts[r['account_id']]['account_manager'])
                for p,r in self.real.items() if p in unresolved and self.by_person[p]
                and self.by_person[p][-1]['date'] < cutoff and total(self.by_person[p]) >= 2500]

    def revenue(self, field, value, date):
        return total(r for r in self.orders.values() if r['customer'][field]==value and period(r['date'],date))

    def zscore(self, region, month):
        values = [self.revenue('region',region,f'2024-{i:02}') for i in range(1,10)]
        return ratio(self.revenue('region',region,month)-mean(values),pstdev(values))

    @staticmethod
    def delay(rows):
        return ratio(sum(r['net']*r['delay'] for r in rows),total(rows))

    def legacy(self, q):
        orders = self.orders.values()
        items = self.items
        customer = lambda r:r['order']['customer']
        segment = lambda r:self.accounts[r['customer']['account_id']]['segment']
        category = lambda r:r['category']
        if m := re.search(r'average number of days between touch and order for campaign (.+?)\?',q):
            days = [(datetime.fromisoformat(r['order']['date'])-datetime.fromisoformat(r['date'])).total_seconds()/86400
                    for r in self.attributed if r['campaign']==m[1]]
            return ratio(sum(days),len(days))
        if m := re.search(r'latest approved refund date for valid order items in the (.+?) category',q):
            return max((r['date'][:10] for r in self.refunds.values()
                        if self.pair_category[r['pair']]==m[1]),default=None)
        if m := re.search(r'How many valid orders were placed by customers in (.+?) during (2024-\d\d)',q):
            return sum(r['customer']['country']==m[1] and period(r['date'],m[2]) for r in orders)
        if m := re.search(r'For (.+?), what is Q4 2024 net revenue from valid orders whose resolved customer',q):
            # Qualify the resolved identity over its full history, then filter raw order geography.
            late_people = {customer(r)['identity'] for r in self.late}
            unresolved = {r['customer']['identity'] for r in self.tickets if r['unresolved'] and r['breach']}
            eligible = {p for p in late_people & unresolved if len(self.by_person[p])>=2}
            return total(r for r in orders if r['customer']['identity'] in eligible
                         and r['customer']['country']==m[1] and period(r['date'],'Q4'))
        if m := re.search(r'For (.+?), aggregate lifetime valid-order net revenue by resolved customer',q):
            grouped = group((r for r in orders if m[1]=='All regions' or r['customer']['region']==m[1]),
                            lambda r:r['customer']['identity'])
            positive = {p:value for p,g in grouped.items() if (value := total(g))>0}
            top_people = rank(positive)[:(len(positive)+9)//10]
            return pct(sum(positive[p] for p in top_people),sum(positive.values()))
        if m := re.search(r'For marketing channel (.+?), calculate 100',q):
            # Aggregate items, shipments and touches separately to avoid fan-out.
            attributed = {r['order']['order_id'] for r in self.attributed if r['marketing_channel']==m[1]}
            margin = total((r for r in items if r['order_id'] in attributed),'margin')
            shipping = sum(D(r['shipping_cost_native'])*self.data.fx(stamp(r['shipped_at']),r['currency'])
                           for r in self.data.table('shipments') if r['order_id'] in attributed
                           and stamp(r['shipped_at'])<=REF)
            spend = sum(D(r['cost_native'])*self.data.fx(r['date'],r['currency'])
                        for r in self.touches if r['marketing_channel']==m[1])
            return pct(margin-shipping-spend,spend)
        if m := re.search(r'first valid order was in (2024-\d\d).*at least (\d+) complete days',q):
            days = int(m[2])
            cutoff = (datetime.fromisoformat(REF)-timedelta(days=days)).isoformat()
            cohort = [g for g in self.by_person.values() if g and period(g[0]['date'],m[1])
                      and g[0]['date']<=cutoff]
            return pct(sum(any(r['date']>g[0]['date'] and window(g[0]['date'],r['date'],days)
                               for r in g[1:]) for g in cohort),len(cohort))
        if m := re.search(r'For valid orders in (.+?), by how many EUR would total net revenue change',q):
            # A larger converted refund reduces net revenue, hence actual minus hypothetical refund.
            delta = D(0)
            for r in self.refunds.values():
                order = self.orders[r['order_id']]
                if m[1]=='All regions' or order['customer']['region']==m[1]:
                    delta += r['eur']-D(r['refund_amount_native'])*self.data.fx(order['date'],r['currency'])
            return delta
        if m := re.search(r'In the (.+?) customer region, among support tickets',q):
            deliveries = group((r for r in self.late if r['delivered'] and customer(r)['region']==m[1]),
                               lambda r:customer(r)['identity'])
            tickets = [t for t in self.tickets if any(window(s['delivered'],t['date'],14)
                       for s in deliveries[t['customer']['identity']])]
            return pct(total(tickets,'breach'),len(tickets))
        if m := re.search(r'For late shipments handled by (.+?),',q):
            return self.delay([r for r in self.late if r['carrier']==m[1]])
        if m := re.search(r'late shipments linked to valid orders in the (.+?) customer region',q):
            return grouped_top((r for r in self.late if customer(r)['region']==m[1]),lambda r:r['carrier'],self.delay)
        if m := re.search(r'items in the (.+?) category(?: during (Q\d) 2024)?, what was the (margin rate|approved-refund rate)',q):
            rows = [r for r in items if category(r)==m[1] and (not m[2] or period(r['order']['date'],m[2]))]
            return pct(total(rows,'margin'),total(rows)) if m[3]=='margin rate' else pct(total(rows,'refund'),total(rows,'gross'))
        if m := re.search(r'net revenue in EUR from customers in (.+?) during (Q\d)',q):
            return self.revenue('country',m[1],m[2])
        if m := re.search(r'For customers in (.+?), what was the percentage growth',q):
            a,b = (self.revenue('country',m[1],quarter) for quarter in ('Q3','Q4'))
            return pct(b-a,a)
        if m := re.search(r'Did net revenue in the (.+?) region .* at least (\d+)%',q):
            a,b = (self.revenue('region',m[1],quarter) for quarter in ('Q3','Q4'))
            return a != 0 and pct(b-a,a) >= int(m[2])
        if 'manager owns the largest' in q:
            return grouped_top(self.at_risk,lambda r:r['manager'],total)
        if 'normalized email domain' in q:
            return grouped_top(orders,lambda r:r['customer']['identity'].rsplit('@',1)[1],total)
        if m := re.search(r'During (Q\d) 2024, which product category had the highest margin',q):
            return grouped_top((r for r in items if period(r['order']['date'],m[1])),category,
                               lambda g:pct(total(g,'margin'),total(g)))
        if m := re.search(r'For the (.+?) region in (Q\d) 2024, what was net revenue as a percentage',q):
            target = sum(D(r['net_revenue_target_eur']) for r in self.data.table('sales_targets')
                         if r['region']==m[1] and period(r['month'],m[2]))
            return pct(self.revenue('region',m[1],m[2]),target)
        if m := re.search(r'accounts in the (.+?) industry had at least one late',q):
            shipped = {customer(r)['account_id'] for r in self.late}
            breached = {r['customer']['account_id'] for r in self.tickets if r['breach']}
            return sum(self.accounts[a]['industry']==m[1] for a in shipped & breached)
        if m := re.search(r'for the (.+?) customer region during (2024-\d\d)',q):
            return self.revenue('region',m[1],m[2])
        if m := re.search(r'accounts in the (.+?) segment, what is the 90th percentile',q):
            values = sorted(total(self.by_account[a]) for a,r in self.accounts.items() if r['segment']==m[1])
            if not values:
                return None
            pos = D(len(values)-1)*D('0.9')
            i = int(pos)
            return values[i]+(pos-i)*(values[min(i+1,len(values)-1)]-values[i])
        if m := re.search(r'For the (.+?) region, what is the z-score of (2024-\d\d)',q):
            return self.zscore(m[1],m[2])
        if m := re.search(r'Which region had the highest net-revenue z-score in (2024-\d\d)',q):
            return top({r:self.zscore(r,m[1]) for r in {c['region'] for c in self.customers.values()}})
        if m := re.search(r'high-value accounts in the (.+?) segment, which issue',q):
            return grouped_top((r for r in self.tickets if segment(r)==m[1]
                               and total(self.by_account[r['customer']['account_id']])>=7000),
                               lambda r:r['issue_type'],len)
        if m := re.search(r'first valid order occurred in (2024-\d\d).*within (\d+) days',q):
            cohort = [g for g in self.by_person.values() if g and period(g[0]['date'],m[1])]
            return pct(sum(len(g)>1 and window(g[0]['date'],g[1]['date'],int(m[2])) for g in cohort),len(cohort))
        if m := re.search(r'from accounts in the (.+?) segment during (Q\d)',q):
            return grouped_top((r for r in items if segment(r['order'])==m[1] and period(r['order']['date'],m[2])),category,total)
        if m := re.search(r'highest-lifetime-revenue account in the (.+?) segment.*from the (.+?) category',q):
            a = top({a:total(self.by_account[a]) for a,r in self.accounts.items() if r['segment']==m[1]})
            return pct(total(r for r in items if customer(r)['account_id']==a and category(r)==m[2]),total(self.by_account[a]))
        if 'Pearson correlation' in q:
            groups = list(group(items,category).values())
            return correlation([float(ratio(total(g,'line_discount'),total(g,'gross'))) for g in groups],
                               [float(ratio(total(g,'refund'),total(g,'gross'))) for g in groups])
        if m := re.search(r"traffic source '(.+?)'",q):
            sessions = group((r for r in self.data.table('web_sessions') if r['traffic_source']==m[1]
                             and r['customer_id'] in self.customers and stamp(r['session_date'])<=REF),
                             lambda r:self.customers[r['customer_id']]['identity'])
            converted = sum(any(window(stamp(s['session_date']),o['date'],14) for s in g for o in self.by_person[p])
                            for p,g in sessions.items())
            return pct(converted,len(sessions))
        if m := re.search(r'marketing channel was (.+?)\?',q):
            return grouped_top((r for r in self.attributed if r['marketing_channel']==m[1]),lambda r:r['campaign'],total)
        if m := re.search(r'items from customers in (.+?), which product category had the highest approved-refund',q):
            return grouped_top((r for r in items if customer(r)['country']==m[1]),category,
                               lambda g:pct(total(g,'refund'),total(g,'gross')))
        if m := re.search(r'Did (.+?) meet or exceed its net revenue target in (2024-\d\d)',q):
            target = sum(D(r['net_revenue_target_eur']) for r in self.data.table('sales_targets') if r['country']==m[1] and r['month']==m[2])
            return self.revenue('country',m[1],m[2])>=target
        if m := re.search(r'at-risk real customers are in (.+?)\?',q):
            return sum(r['country']==m[1] for r in self.at_risk)
        if m := re.search(r'For customers in (.+?) who opened at least one support ticket',q):
            first = {p:min(r['date'] for r in g) for p,g in group(self.tickets,lambda r:r['customer']['identity']).items()}
            return grouped_top((r for r in items if customer(r)['country']==m[1]
                               and r['order']['date']<first.get(customer(r)['identity'],'')),category,total)
        if m := re.search(r'median net revenue per valid order for accounts in the (.+?) segment',q):
            values = [r['net'] for r in orders if segment(r)==m[1]]
            return median(values) if values else None
        if m := re.search(r'unique real customers are in (.+?)\?',q):
            return sum(r['country']==m[1] for r in self.real.values())
        if m := re.search(r'eligible touch for campaign (.+?) and .* issue type (.+?)\?',q):
            touched = {r['person'] for r in self.touches if r['campaign']==m[1]}
            ticketed = {r['customer']['identity'] for r in self.tickets if r['issue_type']==m[2]}
            return sum(total(self.by_person[p]) for p in touched & ticketed)
        if m := re.search(r'In the (.+?) region during (Q\d).*top 3 product categories',q):
            groups = group((r for r in items if customer(r)['region']==m[1] and period(r['order']['date'],m[2])),category)
            return ';'.join(rank({k:total(g) for k,g in groups.items()})[:3])
        if m := re.search(r"raw customer's acquisition channel was (.+?)\?",q):
            return min((r['date'][:10] for r in orders if r['customer']['acquisition_channel']==m[1]),default=None)
        if m := re.search(r'customers in the (.+?) region during (2024-\d\d), which product name',q):
            return grouped_top((r for r in items if customer(r)['region']==m[1] and period(r['order']['date'],m[2])),
                               lambda r:r['product']['product_name'],total)
        if m := re.search(r'real customers acquired through (.+?), what percentage converted',q):
            trials = [r for r in self.real.values() if r['acquisition_channel']==m[1]
                      and r['trial_start_date'] and stamp(r['trial_start_date'])<=REF]
            return pct(sum(bool(self.by_person[r['identity']]) and window(stamp(r['trial_start_date']),
                           self.by_person[r['identity']][0]['date'],30) for r in trials),len(trials))
        if m := re.search(r"support tickets with priority '(.+?)'",q):
            rows = [r for r in self.tickets if r['priority']==m[1]]
            return pct(total(rows,'breach'),len(rows))
        if m := re.search(r'active real customers are in the (.+?) region',q):
            cutoff = (datetime.fromisoformat(REF)-timedelta(days=90)).isoformat()
            return sum(r['region']==m[1] and len(self.by_person[p])>=2 and self.by_person[p][-1]['date']>=cutoff
                       for p,r in self.real.items())
        raise LookupError('Unmapped legacy question')
