using System;

internal static class IntegerSearch
{
    private struct Choice
    {
        internal int Cost, Stock, Dispatch, Supplier;
    }

    private static int[] quantity, stock, dispatch, min, max, fee, used, lower;
    private static int[,] reachable;
    private static Choice[][] jobs;
    private static int best;

    private static void Visit(int job, int cost)
    {
        int possibleCredit = 0;
        for (int s = 0; s < used.Length; s++)
        {
            if (used[s] > 0 && used[s] + reachable[job,s] < min[s]) return;
            if (used[s] == 0 && reachable[job,s] > 0 && fee[s] < 0) possibleCredit += fee[s];
        }
        if (cost + lower[job] + possibleCredit >= best) return;
        if (job == jobs.Length)
        {
            best = cost;
            return;
        }

        // Relax shared resource use while respecting each job's individual feasibility.
        int bound = cost + possibleCredit;
        for (int j = job; j < jobs.Length; j++)
        {
            foreach (Choice option in jobs[j])
                if (Fits(option, quantity[j]))
                {
                    bound += option.Cost;
                    break;
                }
            if (bound + lower[j+1] >= best) return;
        }

        int units = quantity[job];
        foreach (Choice option in jobs[job])
        {
            if (!Fits(option, units)) continue;
            int supplier = option.Supplier;
            if (supplier < 0)
            {
                Visit(job+1, cost+option.Cost);
                continue;
            }
            int activation = used[supplier] == 0 ? fee[supplier] : 0;
            stock[option.Stock] -= units;
            dispatch[option.Dispatch] -= units;
            used[supplier] += units;
            Visit(job+1, cost+option.Cost+activation);
            used[supplier] -= units;
            dispatch[option.Dispatch] += units;
            stock[option.Stock] += units;
        }
    }

    private static bool Fits(Choice option, int units)
    {
        return option.Supplier < 0 ||
               (stock[option.Stock] >= units && dispatch[option.Dispatch] >= units &&
                used[option.Supplier] + units <= max[option.Supplier]);
    }

    private static void Main()
    {
        // Python supplies integer costs and prefiltered alternatives using the same model as its fallback.
        string[] input = Console.In.ReadToEnd().Split((char[])null, StringSplitOptions.RemoveEmptyEntries);
        int pos = 0;
        Func<int> next = delegate { return int.Parse(input[pos++]); };
        int n = next(), stockCount = next(), dispatchCount = next(), supplierCount = next();
        stock = new int[stockCount];
        dispatch = new int[dispatchCount];
        for (int i = 0; i < stockCount; i++) stock[i] = next();
        for (int i = 0; i < dispatchCount; i++) dispatch[i] = next();
        min = new int[supplierCount]; max = new int[supplierCount]; fee = new int[supplierCount];
        used = new int[supplierCount];
        for (int s = 0; s < supplierCount; s++)
        {
            min[s] = next(); max[s] = next(); fee[s] = next();
        }
        jobs = new Choice[n][];
        quantity = new int[n];
        for (int j = 0; j < n; j++)
        {
            quantity[j] = next();
            jobs[j] = new Choice[next()];
            for (int k = 0; k < jobs[j].Length; k++)
            {
                Choice option = new Choice { Cost=next(), Stock=next(), Dispatch=next(), Supplier=next() };
                jobs[j][k] = option;
                if (option.Supplier < 0) best += option.Cost;
            }
        }
        lower = new int[n+1];
        reachable = new int[n+1,supplierCount];
        for (int j = n-1; j >= 0; j--)
        {
            lower[j] = lower[j+1] + jobs[j][0].Cost;
            for (int s = 0; s < supplierCount; s++)
            {
                reachable[j,s] = reachable[j+1,s];
                if (Array.Exists(jobs[j], option => option.Supplier == s)) reachable[j,s] += quantity[j];
            }
        }
        Visit(0,0);
        Console.WriteLine(best);
    }
}
