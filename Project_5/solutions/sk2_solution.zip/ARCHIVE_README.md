# SK² - submitted Project 5 solution

Source: [Karen2007/sixt-hackathon-2026](https://github.com/Karen2007/sixt-hackathon-2026/tree/7bbefd79487ebefdf5e131cdc0f75230652891b2/Project_5), commit `7bbefd79487ebefdf5e131cdc0f75230652891b2`.

This archive contains the reviewed team-authored submission files with their original `Project_5/` layout, plus the source repository's `LICENSE`. The files are preserved byte for byte. `SOURCE_MANIFEST.json` records every included source path and checksum, and lists omitted organizer material or generated files.

Extract this archive into a separate working copy of the challenge repository so that `Project_5/` is at the repository root. Read `Project_5/SUBMISSION.md` and the implementation README files before running anything. Programs were not executed during archiving.

Download the official [Stage 1 release](https://github.com/sixt-hackathon-2026/sixt-hackathon-2026/blob/main/Project_5/releases/problem7_student_start.zip) and [Stage 2 release](https://github.com/sixt-hackathon-2026/sixt-hackathon-2026/blob/main/Project_5/releases/problem7_student_final.zip) separately. Restore the release/example files from the main repository and extract the datasets at the exact paths required by the team's instructions. Install the team's declared dependencies and obtain any model access separately.

The canonical scored files are `Project_5/public_answers.csv` and, when present, `Project_5/final_answers.csv`. Other answer copies, experiments, logs and intermediate outputs retain the meanings stated by their authors. Student answers are not an organizer answer key.

The archive preserves the team's own report and slides, including statements that may have been superseded by the organizer's later provisional results or bonus rulings. Refer to the Project 5 results sheet for those decisions.

Stage 2 answers were not submitted in this reviewed snapshot. No replacement answer file has been invented or generated.
