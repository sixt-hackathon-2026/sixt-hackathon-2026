"""Check CSV structure without reading any gold answers.

Missing or blank answers are allowed and reported; they receive zero in grading.
This checks the submission format, not factual correctness.
"""
import argparse
import csv
import sys
from pathlib import Path


def rows(path, exact_header=False):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream, strict=True)
        columns = reader.fieldnames or []
        if exact_header and columns != ['question_id', 'answer']:
            raise ValueError('The submission header must be exactly question_id,answer.')
        if 'question_id' not in columns or len(columns) != len(set(columns)):
            raise ValueError('Invalid question_id header.')
        found = {}
        for number, row in enumerate(reader, 2):
            if None in row or any(value is None for value in row.values()):
                raise ValueError(f'Missing or extra CSV field on row {number}.')
            key = row['question_id'].strip()
            if not key or key in found:
                raise ValueError(f'Empty or duplicate question ID on row {number}: {key!r}.')
            found[key] = row
    return found


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--questions', type=Path, required=True)
    parser.add_argument('--submission', type=Path, required=True)
    args = parser.parse_args()
    try:
        questions = rows(args.questions)
        submitted = rows(args.submission, exact_header=True)
        unknown = set(submitted) - set(questions)
        if unknown:
            raise ValueError('Unknown question IDs: ' + ', '.join(sorted(unknown)))
        answered = sum(bool(row['answer'].strip()) for row in submitted.values())
    except (ValueError, OSError, UnicodeError, csv.Error) as error:
        print('FORMAT ERROR: ' + str(error), file=sys.stderr)
        return 2
    print(f'FORMAT OK: {len(submitted)} rows; {answered} nonblank answers; '
          f'{len(questions)-answered} missing or blank of {len(questions)} questions.')
    print('This check does not evaluate whether any answer is correct.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
