# Version 7 calculation rules - final

Questions 001-150 retain the earlier metric definitions below, including the raw-customer acquisition-channel clarification. Questions 151-180 use only the hard_opt_* scenario tables and their rules; questions 181-200 use only the flow_* scenario tables and their rules. Scenario identities link to the company snapshot for context. Do not apply inherited customer exclusion, FX, reference-time or aggregation rules to scenario tables unless the scenario rules explicitly require it. All scenario money is in integer EUR cents.

For earliest-valid-order-date-by-acquisition-channel questions, use the raw customer linked directly to the order, not its canonical resolved customer.

The event grade is defined in EVENT_RULES.md; stages are released only on explicit organizer instruction.

## Coupled fulfilment decision cases (hard_opt_*.csv)

These are separate synthetic decision scenarios. A case's stock, capacities,
costs and supplier conditions are given only by its `hard_opt_*` rows. Product,
warehouse and supplier identifiers refer to the supplied catalog identities;
do not import operational balances, FX, contract dates, order-validity rules or
costs from other datasets into these cases. All monetary inputs are integer
euro cents. Day numbers are integer offsets from the case's day_origin.

For each case, independently choose either one listed fulfilment option for a
job or leave that whole job unfilled. Splitting a job or using two options for
it is forbidden. Options that fail any condition below cannot be chosen.

1. An option dispatches the job's entire quantity from its named warehouse.
   Dispatch must be on or after the job's ready_day. Arrival is dispatch_day
   plus that option's supplier lead_days. Arrival must be on or before last_day.
   The supplier must have active=1. Equality at either boundary is allowed.
2. Selected quantities cannot exceed available_units for any warehouse/product
   pair or capacity_units for any warehouse/dispatch-day pair. Stock is a fixed
   case-wide pool; there is no replenishment and no carry-over between cases.
   Dispatch capacity counts units, not jobs. A supplier's assignment quantity
   sums all selected job quantities across warehouses and days.
3. Each used supplier must receive at least minimum_units and at most maximum_units.
   An unused supplier receives zero and incurs no activation cost. A used
   supplier incurs activation_cost_cents exactly once per case. Supplier fees
   are not charged once per option, warehouse or day.
4. A selected option costs variable_cost_cents in total for the whole job,
   plus quantity * late_penalty_cents_per_unit_day * max(0, arrival_day-due_day).
   Do not multiply variable_cost_cents by quantity. An unfilled job incurs its
   unfilled_penalty_cents once, and no variable, late or supplier-activation
   cost on its own. An active supplier is not automatically a used supplier.
5. Minimize the sum of option costs, lateness costs, activation costs and
   unfilled-job penalties. The all-unfilled plan is feasible. No requirement
   to fulfil a fixed number of jobs or exhaust capacity is implied.
6. The counterfactual applies every row in hard_opt_changes.csv for that case
   simultaneously as an exact field replacement, then reoptimizes all choices
   from scratch. A stock change targets warehouse_region + product_id; a
   dispatch change targets warehouse_region + dispatch_day; a supplier change
   targets supplier_id. Blank selector columns are not wildcard matches.
   table_name is stock, dispatch or suppliers. No target/field occurs twice.
   Other fields remain unchanged. Baseline questions ignore all change rows.
7. Cost change means (minimum counterfactual cost - minimum baseline cost).
   It may be negative. Divide integer cents by 100 once at the end and return
   EUR with two decimal places. Multiple optimal plans are allowed because
   their minimum cost is identical. No particular plan is required in the CSV.

Proposed options intentionally include some unavailable or too-late alternatives;
apply the stated rules before optimizing. These rules fully define both stages.


## Stateful fulfilment simulations (flow_* tables)

These cases are separate synthetic operational scenarios. Product, warehouse and
customer keys refer to identities in the stage's existing tables. Use only the
five flow_* tables to calculate a flow case: do not add the original orders,
payments, inventory, contracts or business exclusions to these simulations.
Each case starts independently with its listed opening stock and no orders in
progress. All money is integer EUR cents; return the final monetary answer in
EUR with two decimal places. No tax, FX conversion or unstated costs apply.

**Known versions.** For each (case_id,event_id), retain versions whose
recorded_step <= knowledge_cutoff_step, then select the greatest
(recorded_step,version_id), comparing version_id lexicographically. Select before
checking status or effective_step. A selected void version removes that event;
otherwise use it only when effective_step <= horizon_step. Apply the same known
version selection to (case_id,customer_id) in flow_contracts. A selected inactive
contract gives priority 99 and no rebate. Contract terms apply throughout the
case; they are not a second time series of actions. Physical CSV row order and
the numerical appearance of version IDs do not establish precedence.

**Event order.** An order releases at release_step. Combine these releases with
the selected events and process ascending effective_step, then action priority
CANCEL, RETURN, RECEIPT, RELEASE, DISPATCH, then lexical event_id (order_id for a
release). Releases after the horizon are not processed. At the horizon, finish
all actions at that step before calculating the result. A deadline is met when
a dispatch occurs at or before deadline_step.

**Reservations.** At release, the order's requested units join its one product
and warehouse queue. After every action, allocate free stock to released,
uncancelled, unshipped, unreserved units in ascending (contract priority,
deadline_step,release_step,order_id). Partial reservations are allowed. Existing
reservations are sticky: a later higher-priority order cannot take them. Within
an order, units have sequence numbers 1..units. Reserve and dispatch the lowest
available sequence numbers first. Reservations remove units from free stock.

**RECEIPT** adds its units to free stock for the listed product/warehouse.
**CANCEL** cancels up to its units of the referenced order's currently released,
uncancelled, unshipped units, lowest unit sequence first, whether reserved or
not. Freed reservations return to free stock. Requested units that cannot be
cancelled are ignored. Each actually cancelled unit earns cancellation_fee_cents.
**DISPATCH** provides a one-use warehouse capacity of units across all products.
Among that warehouse's orders with reservations, dispatch in the same queue
order, up to capacity, including partial orders. Unused capacity expires.
There is no automatic shipment at another time.
**RETURN** returns up to its units of the referenced order's already dispatched,
not-yet-returned units, latest dispatch first and highest sequence first within
a dispatch. A return for an unshipped unit has no effect. Every actual return
refunds the full unit price and incurs return_fee_cents. If restock is true it
also adds one unit to free stock and recovers unit_cost_cents; otherwise neither
stock nor cost is recovered. Prior late penalties are never reversed.

**Net contribution.** Sum retained sales revenue, subtract cost of every
dispatched unit, add cost recovered on restocked returns, subtract late penalties
for every unit dispatched strictly after its deadline, subtract unfilled
penalties for released units still neither dispatched nor cancelled at the
horizon, add cancellation fees and subtract return fees. Returned units do not
become unfilled orders. For each customer, count retained (dispatched minus
returned) units across all its orders in this case. If that count is at least
rebate_threshold_units, subtract rebate_per_unit_cents for *every* retained
unit of that customer, not only units above the threshold.

**Declared what-if.** First select known event versions exactly as above. Apply
first_action, then second_action when present, to the indicated selected event:
SHIFT adds the integer value to effective_step; SET_UNITS replaces units with
the integer value. Event IDs, known versions and all other facts stay fixed.
Reapply the horizon filter after edits, and replay from the original opening
state. The second edit does not start from the baseline's closing state. A
question asking for a change means what-if contribution minus baseline
contribution, signed. No scenario edits apply to baseline questions.


## Retained metric definitions

# Business rules for version 6.0.0

These definitions are authoritative for both releases. All timestamps are naive UTC. The reference time is **2025-01-01 00:00:00 UTC**. A date without a time means midnight. Use exact timestamps for elapsed-time windows; do not floor fractional days. “Lifetime” means all eligible observations in this snapshot up to and including the reference time. Quarter filters are half-open calendar quarters in 2024. No inference about activity before the provided observations is required.

## Eligible records and valid orders

A raw customer is eligible if neither the customer nor its linked account is flagged as test. Resolve identities only after applying this exclusion. An order is valid when its date is at or before the reference, its status is completed or shipped, payment status is paid, at least one linked payment is settled with payment date at or before the reference, fraud flag is false, duplicate flag is false, and its raw customer is eligible. A payment is an existence condition: multiple settled rows never duplicate an order or its items. Do not use payment amounts as revenue. Count distinct order IDs.

For support tickets, marketing touches, and web sessions, exclude ineligible raw customers and events created after the reference. For shipments, include only valid linked orders and shipment creation dates at or before the reference. Ignore refunds after the reference, even when their status is approved. Future events remain in the files deliberately.

## Resolved identity and dimensions

Trim and lowercase email; remove the local-part plus tag on every domain; remove local-part dots for gmail.com and googlemail.com; map googlemail.com to gmail.com. The result is the resolved identity.

For a metric grouping real customers, choose the eligible raw row with earliest signup timestamp, then lexicographically smallest customer ID, as the canonical row. Use its country, region, account, manager, acquisition channel, and trial start. Exclude canonical candidates signed up after the reference. Aggregate orders and tickets across all eligible aliases. For order/item/attribution/shipments metrics, use the raw customer on the order for geography and account; support and web metrics retain their own raw-customer dimensions unless the question says resolved customer. Thus aliases can contribute orders to different countries while counting as one canonical real customer. Account metrics exclude test accounts, include eligible accounts with zero revenue, and use the order's account.

## FX and item revenue

Convert native amount to EUR by multiplying by the matching monthly rate. Item price, line discount, and order discount use order month and order currency. Product cost uses order month and product cost currency. Approved eligible refunds use refund month and refund currency. Marketing cost uses touch month/currency; shipping cost uses shipment month/currency. EUR-to-EUR is exactly 1.000000 for every month and is explicitly anchored in V6. For all non-EUR currencies, use the supplied monthly rate; do not substitute 1 for a missing rate.

For each item, gross native = quantity * unit price; pre-discount native = gross native - line discount. Allocate the order discount across all its item lines in proportion to pre-discount native. If the sum is zero, allocate zero (the release has no nonzero order discount with a zero denominator). Convert gross, line discount, and allocated order discount to EUR without intermediate rounding.

Aggregate eligible approved refunds by (order ID, product ID). When a product occurs on multiple lines, allocate that aggregate across those lines in proportion to max(pre-discount native, 0); if all weights are zero, split equally. Subtract each refund exactly once overall. Refunds are attributed to the original order period and the product category at order time, not to the refund period. Net item revenue = gross EUR - line discount EUR - allocated order discount EUR - allocated refund EUR. Order revenue is its item sum. Net revenue can be negative; do not clip it.

## Categories and margin

Use product category history with valid_from <= order timestamp <= valid_to. Exactly one interval must match each item; never use only the current/default category. Item cost = quantity * standard cost * cost-currency FX in order month. Item margin = item net revenue - item cost. Margin rate = total margin / total net revenue, not the average of item ratios.

## Customer and account status

High-value real customer: lifetime valid-order net revenue >= EUR 2,500. Active: at least two distinct valid orders and last order >= reference minus 90 days. At-risk: high-value, last order strictly before reference minus 75 days, and at least one eligible unresolved support ticket. A ticket with no resolution by the reference is unresolved, regardless of its later snapshot status label. High-value account: lifetime valid-order net revenue >= EUR 7,000.

## Support and shipment timing

SLA thresholds in hours: urgent 24, high 48, medium 72, low 120. Use resolved_at only when it is at or before reference; otherwise use reference. A breach requires elapsed hours strictly greater than the threshold. A future resolution means unresolved at reference.

A shipment delivered after reference is undelivered at reference. Its effective delivery is the known delivery at or before reference, else reference. Delay days are max(0, calendar date of effective delivery minus calendar date of promise). A shipment is late when this delay is positive and promise is before reference. A ticket within 14 days after a late delivery must have a delivered shipment at or before reference, on the same resolved identity, and 0 <= opened_at - delivered_at <= 14 exact days. Count each qualifying ticket once even when multiple shipments match. The region filter in this question selects shipment/order customer region. Ticket country/region need not match the shipment if an alias moved.

Revenue-weighted shipment delay uses order net revenue as the weight for each qualifying shipment. Multiple shipments each receive that weight. Shipping cost metrics sum each shipment cost once.

## Marketing and conversion

Attribute each valid order to the eligible touch on its resolved identity with 0 <= order timestamp - touch timestamp <= 30 days. Choose latest touch timestamp, then alphabetically first campaign, then smallest touch ID. Do not choose by floored days. Unattributed orders contribute zero to attributed aggregates. Channel touch spend includes all eligible touches in that channel, including those that do not convert.

Ordinary cohort retention uses customers whose first valid order month matches the question; another distinct order within the stated elapsed N days counts, including a second order at the same timestamp. Include customers with shorter available follow-up in this ordinary denominator. A question explicitly requesting a fully observed cohort instead excludes customers whose first order is less than N days before reference and can require strictly later purchases. Trial conversion uses canonical eligible customers in the channel with a nonmissing trial start at or before reference; their first valid order must occur from trial start through 30 exact days later. Web conversion is the fraction of distinct resolved customers with a qualifying-source session that have at least one valid order from the session through 14 exact days later.

## Statistics and output

Revenue targets are EUR; sum the stated months and geography. P90 uses linear interpolation at index (n-1)*0.9 over all eligible accounts in the segment, including zero-revenue accounts. Median uses the mean of the two middle values when even. Z-scores use all nine Jan-Sep months, zero for a month with no revenue, and population standard deviation (ddof=0). Correlation is Pearson across categories between total line discount / gross and approved allocated refunds / gross; order-level discounts are excluded from this particular discount rate.

“All regions” means the union of every customer region in the data, not a missing fourth region. Question-specific definitions take precedence for the named metric. Ranking ties use alphabetically first label; output rankings in descending value with alphabetic ties. Top-three output uses semicolons in ranking order. Keep full precision until final formatting. Integers are exact counts; numeric answers are rounded to two decimals (Python round-to-nearest, ties-to-even); booleans true/false; dates YYYY-MM-DD. Undefined ratios, correlations, statistics on empty populations, or missing dates use N/A; a sum over no records is zero. No scored V6 item has undefined gold.

The scorer accepts numeric absolute error <=0.01 with no relative tolerance; integer values must be mathematically integral and equal. Strings ignore case and repeated surrounding/inter-word spaces but preserve ranking order. Booleans also accept t/f, yes/no, y/n, and 1/0. N/A is correct only when gold is N/A. Submit exactly question_id,answer columns; duplicate or unknown IDs invalidate the file, and missing/blank answers score incorrect. The denominator remains all 200 questions.


# Additional V6 business rules

Version 6.0.0 retains the original answer-CSV event. There are 200 public and 200 final scored questions, weighted 35/65, plus ten unscored worked examples. Each stage contains the corrected 17 base tables and eight new tables. The original simulator is unavailable; V6 is a documented transformation of the supplied snapshots and seeded construction of linked records. No frontier/scheduling artifacts are inputs.

Reference: 2025-01-01 00:00:00 UTC. Timestamps are naive UTC. New intervals are half-open `[valid_from, valid_to)`. Currency amounts remain unrounded until the final two-decimal ties-to-even answer. EUR-to-EUR is explicitly 1.000000 for every supplied month; the builder records every changed EUR row, preserves non-EUR rates, and recomputes all legacy answers. Missing non-EUR rates are an integrity error, not an assumed unit rate. All 100 public and 100 final question IDs/texts from the corrected V2 scalar edition are retained.

## Eight additional tables

1. **suppliers**: supplier_id (PK), supplier_name, country, contract_start, contract_end, is_test_supplier. A supplier is eligible for a purchase line when non-test and `contract_start <= ordered_at < contract_end`.
2. **purchase_order_lines**: po_line_id (PK), supplier_id, product_id, warehouse_region, ordered_at, promised_at, ordered_units, unit_cost_native, currency, status. Eligible lines have status `open` or `closed`, ordered_at <= reference, and an eligible supplier. Status `cancelled` is excluded. Product/warehouse keys exist in the base stocktake table. Commitment = ordered_units * unit_cost_native * FX at ordered_at; status closed does not erase commitment.
3. **goods_receipts**: receipt_id (PK), po_line_id, received_at, accepted_units, rejected_units, status. Eligible receipts have status `posted`, `ordered_at <= received_at <= reference`, and eligible linked purchase line. `void` and future rows are ignored. Partial and multiple receipts are legitimate; accepted/rejected counts sum by line. Over-receipt is permitted. Remaining units = max(0, ordered_units - accepted units). Rejected units do not fulfil a purchase line. Received cost uses receipt-month FX in the purchase currency, not purchase-month FX.
4. **inventory_movements**: movement_id (PK), product_id, warehouse_region, event_at, movement_type, units_delta, source_id, status. Posted movements only. Types are `receipt` (positive, source receipt_id), `return_restock` (positive, source inspection_id), `sale_issue` (negative, source order_item_id), `adjustment` (signed, source_id blank). Every movement is counted once by movement_id; source_id is provenance, not a deduplication key. Opening stock is base warehouse_inventory.on_hand_units at last_stocktake_date. End stock = opening + sum posted deltas with stocktake timestamp < event_at <= reference. Do not add receipts/inspections a second time. The generated ledger has no negative end stocks. It is a constructed ledger linked to sampled base fulfilment records, not a reconstruction of a missing original warehouse simulator.
5. **stock_policies**: product_id, warehouse_region, valid_from, valid_to (composite key), reorder_point, target_units. Selected policy is the unique row whose interval contains reference. Intervals per product/warehouse do not overlap. All stock keys have exactly one applicable policy. Reorder when end stock < reorder_point; suggested units then max(0,target_units-end stock), otherwise zero. No reorder is triggered at equality.
6. **return_inspections**: inspection_id (PK), refund_id, warehouse_region, inspected_at, units_received, restockable_units, recovery_unit_value_eur, disposition, status. Eligible inspection: status `completed`; eligible approved refund on a valid order and valid order/product pair; refund_date <= inspected_at <= reference. Multiple inspections per refund are allowed and have distinct IDs. Sum their units/value; do not multiply refund amount by inspection count. Every row has 0 <= restockable_units <= units_received. Recovery = restockable_units * recovery_unit_value_eur. Value is already EUR. A refund with no eligible inspection is uninspected. Category is the refunded product's category at original order time.
7. **support_worklogs**: worklog_id (PK), ticket_id, worked_at, minutes_worked, hourly_rate_native, currency, work_status, is_billable. Eligible worklog: work_status `approved`, eligible base ticket, opened_at <= worked_at <= reference. `draft` rows are excluded. Work after ticket resolution may be legitimate follow-up and remains eligible. Labor EUR = minutes_worked/60 * hourly_rate_native * worked-month FX. Billable is a classification, not a second revenue source. Ticket geography/account/issue/channel comes from its eligible raw customer, not canonical identity. A ticket may have zero or many logs.
8. **account_contract_versions**: contract_id, account_id, revision, recorded_at (unique version tuple), valid_from, valid_to, status, service_credit_eur, quarterly_fee_eur, included_support_minutes. Select the version with greatest `(recorded_at, revision)` among recorded_at <= reference for each contract_id, then keep active status and apply the valid interval. Ties in that tuple are forbidden by the data integrity checks. Selected active intervals do not overlap per account. Ignore test accounts. A ticket is covered when the selected active contract interval contains its opened_at. Each covered base-SLA-breached ticket incurs exactly one fixed service_credit_eur; breach uses the existing snapshot-censored SLA rule. Multiple logs do not multiply a credit. The quarterly fee metric is explicitly the **contracted quarterly run-rate at reference**, not historical recognized fees or a prorated invoice. Q4 included minutes use the contract applicable at 2024-10-01 00:00:00 and compare its quota to all eligible Q4 account worklogs; accounts without such a contract are excluded from that quota metric.

## Recipe blueprint

All added questions use at least one added table. Initial and final each contain four explicit parameter instances of 25 new recipes: 20 shared, five initial-only, five final-only. This adds 30 distinct recipes, rather than only more parameter instances of existing recipes. Difficulty tiers are author design judgments, not measured student difficulty. Existing recipes remain unchanged except the explicit EUR-anchor correction to their data.

### Twenty shared recipes

| Kind | Filter parameters | Formula / output |
|---|---|---|
| procurement_commitment | supplier_country | Sum eligible purchase commitments, purchase-month FX |
| procurement_open_units | warehouse | Sum remaining units over eligible purchase lines |
| procurement_on_time_pct | supplier_country | Due eligible lines (promised_at <= reference): 100 * sum(min(ordered units, accepted units received <= promised_at)) / sum(ordered units) |
| procurement_rejection_pct | supplier_country | 100 * eligible rejected receipt units / eligible accepted+rejected receipt units |
| procurement_price_variance | family | Sum ordered units * (purchase unit EUR minus product standard-cost EUR), both using purchase month; positive means purchase price exceeds standard cost |
| procurement_received_cost | warehouse | Sum accepted units * unit purchase price * receipt-month FX |
| procurement_worst_supplier | supplier_country | Supplier name with highest rejection rate among suppliers with a positive receipt-unit denominator; alphabetical ties |
| inventory_on_hand | warehouse | Sum reconciled end stock |
| inventory_value | warehouse | Sum end stock * product standard cost * cost-currency FX for reference month 2025-01 |
| inventory_below_reorder | warehouse | Count product/warehouse keys strictly below selected policy reorder point |
| inventory_reorder_units | warehouse | Sum suggested replenishment quantities |
| returns_restockable_pct | refund_reason | 100 * sum restockable / sum received units across eligible inspections |
| returns_recovered_value | category | Sum eligible recovery EUR in order-time category |
| returns_uninspected | refund_reason | Count distinct eligible approved valid-order/product refunds with no eligible inspection |
| support_labor_cost | issue_type | Sum eligible worklog labor EUR |
| support_billable_hours | support_channel | Sum eligible billable minutes / 60 |
| support_costliest_issue | country | Issue with highest total eligible labor cost / count of all eligible tickets in that issue/country, including tickets with zero worklogs; alphabetical ties |
| contracts_ticket_coverage_pct | segment | 100 * covered eligible tickets / all eligible tickets in raw-customer account segment |
| contracts_service_credits | segment | Sum fixed credits for covered SLA-breached eligible tickets |
| support_total_service_cost | segment | Eligible worklog labor EUR plus covered breached-ticket credits |

### Five initial-only recipes

| Kind | Filter | Formula / output |
|---|---|---|
| contracts_quarterly_run_rate | segment | Sum quarterly_fee_eur once for each eligible account's selected contract at reference |
| procurement_receipt_count | supplier_country | Count eligible receipt IDs |
| procurement_top_supplier_units | family | Supplier name with greatest accepted eligible receipt units for products in family; alphabetical ties |
| inventory_adjustment_units | warehouse | Sum posted adjustment deltas strictly after each stocktake and through reference |
| support_unlogged_tickets | issue_type | Count eligible ticket IDs with no eligible worklog |

### Five final-only recipes

| Kind | Filter | Formula / output |
|---|---|---|
| support_adjusted_margin | segment | Lifetime valid-item margin for raw-order account segment minus eligible labor cost and covered breached-ticket credits for that segment |
| inventory_issue_coverage_days | warehouse | Aggregate end stock / (absolute posted sale_issue units in Q4 / 92). Q4 is [2024-10-01,2025-01-01); movements must also be strictly after their stocktake. No issue demand => N/A |
| procurement_due_shortfall_value | supplier_country | Sum max(0,ordered units-accepted eligible units) * purchase unit native * purchase-month FX for eligible lines promised by reference |
| returns_recovery_adjusted_rate | category | 100 * (eligible approved refund EUR - eligible recovered inspection EUR) / valid-item gross EUR in order-time category; each refund once and each inspection once |
| contracts_q4_overage_minutes | segment | Sum max(0,Q4 eligible account worklog minutes - selected Q4-start included_support_minutes) over eligible accounts with a Q4-start contract |

Empty sums/counts are zero. Undefined ratios and rankings on no candidates are N/A; scored parameters will be validated to avoid accidental empty definitions, without substituting zero for undefined values. All four-per-recipe parameter combinations are declared in specs before gold calculation, not selected by model score.

