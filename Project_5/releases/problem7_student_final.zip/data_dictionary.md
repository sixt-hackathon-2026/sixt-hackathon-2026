# Version 7 data dictionary

## Coupled fulfilment tables

All case_id and job_id references are exact joins. Rows have no implicit order.

| File | Row meaning and key | Fields |
|---|---|---|
| hard_opt_cases.csv | One independent scenario; case_id | day_origin is the calendar origin for integer day offsets; notes describes the synthetic scope. |
| hard_opt_jobs.csv | One indivisible job; case_id + job_id | product_id; quantity > 0; ready_day; due_day; last_day; late_penalty_cents_per_unit_day; unfilled_penalty_cents (total job penalty). |
| hard_opt_options.csv | One proposed alternative; case_id + option_id | job_id; warehouse_region; supplier_id; dispatch_day; variable_cost_cents (total for this option, not a unit price). |
| hard_opt_stock.csv | Fixed stock pool; case_id + warehouse_region + product_id | available_units, a nonnegative integer. |
| hard_opt_dispatch.csv | Shared daily unit capacity; case_id + warehouse_region + dispatch_day | capacity_units, a nonnegative integer. |
| hard_opt_suppliers.csv | Scenario supplier conditions; case_id + supplier_id | lead_days >= 0; activation_cost_cents; minimum_units; maximum_units; active (1 or 0). Minimum applies only if used. |
| hard_opt_changes.csv | Counterfactual field override; case_id + change_id | table_name; target selector columns; field; new_value. Allowed fields: stock.available_units, dispatch.capacity_units, suppliers.active/lead_days/activation_cost_cents/minimum_units/maximum_units. Empty target columns are unused. |

All costs are euro cents; no FX conversion applies. Day offsets and capacity
units are integers. Different cases never share stock, capacity, jobs or fees.


## Flow simulation CSV columns

- `flow_cases.csv`: one row per scenario. `horizon_step` is the inclusive action
  cutoff; `knowledge_cutoff_step` is the inclusive recorded-version cutoff.
  `first_*` and optional `second_*` define the stated what-if; an empty second
  event/action means no second intervention. Steps are integer logical times,
  not dates, and are comparable only within their case.
- `flow_stock.csv`: unique (case_id,product_id,warehouse) opening free units.
- `flow_orders.csv`: unique order_id within a case, linked customer/product and
  warehouse, release and deadline steps, requested units, and explicit integer
  EUR-cent price, cost, late/unfilled penalties, cancellation and return fees.
- `flow_events.csv`: versioned action rows. event_type is RECEIPT, CANCEL,
  RETURN or DISPATCH. Product/warehouse are used for receipts; warehouse alone
  for dispatches; order_id for cancellation/return. Empty unused identifiers
  carry no meaning. units is a nonnegative integer; restock is true/false;
  status is posted/void. recorded_step is observation time, effective_step is
  action time; version_id is a lexical tie-break only.
- `flow_contracts.csv`: versioned customer terms per case. priority is an integer
  (smaller means earlier); rebate_threshold_units and rebate_per_unit_cents
  determine the end-of-case rebate; status is active/inactive. recorded_step and
  version_id select the known version exactly as for events.


## Retained 25-table schema

# Data Dictionary — Final Release

The final release intentionally uses schema/column-name drift. The business concepts are the same as the initial release, but many columns have different names.

Use this dictionary instead of hard-coding initial-release column names.

## accounts.csv
- `acct_id` = account identifier
- `acct_name` = account display name
- `segment`
- `industry`
- `billing_country` = account country
- `sales_region` = account region
- `account_manager`
- `acct_start_dt` = account start date
- `test_acct_flag` = test account flag

## customers.csv
- `cust_id` = raw customer identifier
- `acct_id` = linked account
- `email_address` = raw email for identity resolution
- `country`, `region`
- `acquisition_channel`
- `signup_dt`, `trial_start_dt`
- `test_customer_flag`

## orders.csv
- `order_key` = order identifier
- `cust_id` = linked customer
- `order_dt` = order date
- `lifecycle_status` = order status
- `pay_status` = payment status
- `order_ccy` = order currency
- `promo_code` = coupon code
- `order_discount_native` = order-level discount in native currency
- `risk_hold_flag` = fraud/risk flag
- `is_duplicate`
- `duplicate_of` = original order if duplicate
- `source` = source channel

## order_items.csv
- `line_id` = order item identifier
- `order_key`
- `sku` = product identifier
- `qty`
- `unit_price_native`
- `line_discount_native`

## payments.csv
- `payment_key`
- `order_key`
- `paid_dt`
- `payment_state` = payment status detail
- `payment_ccy`
- `payment_amount_native`

## refunds.csv
- `refund_key`
- `order_key`
- `sku`
- `refund_dt`
- `refund_ccy`
- `refund_amount_native`
- `refund_state`
- `refund_reason`

## products.csv
- `sku`
- `sku_name`
- `default_category`
- `family`
- `list_eur`
- `std_cost`
- `cost_ccy`
- `launch_dt`

## product_category_history.csv
- `sku`
- `business_category`
- `category_valid_from`
- `category_valid_to`

## shipments.csv
- `shipment_key`
- `order_key`
- `carrier`
- `ship_dt`
- `promise_dt`
- `delivery_dt`
- `fulfillment_region`
- `shipping_cost_native`
- `ship_ccy`

## support_tickets.csv
- `case_id`
- `cust_id`
- `related_order_key`
- `opened_ts`
- `resolved_ts`
- `case_topic` = issue type
- `case_priority` = priority
- `case_status`
- `case_channel`
- `sentiment_score`
- `escalated`

## marketing_touches.csv
- `touch_key`
- `cust_id`
- `touch_dt`
- `mkt_channel` = marketing channel (initial-schema alias: `marketing_channel`)
- `campaign`
- `cost_ccy`
- `touch_cost_native`

## fx_rates.csv
- `rate_month`
- `ccy`
- `to_eur`

## sales_targets.csv
- `target_month`
- `country`
- `region`
- `target_eur`

## Additional tables and stocktake anchors
- `web_sessions.csv`: `session_id`, `cust_id`, `session_dt`, `traffic_source`, `page_views`, `minutes_on_site`
- `employee_regions.csv`: mostly distractor
- `warehouse_inventory.csv`: required V6 stocktake anchors; `sku` is product ID, with `warehouse_region`, `on_hand_units` and `last_stocktake_date`
- `promotions.csv`: mostly distractor


## V6 added business tables

The eight new tables retain the same column names in both stages. The inherited final-stage aliases above remain in use. Exact semantics and key constraints are in business_rules.md.

### suppliers.csv

`supplier_id`, `supplier_name`, `country`, `contract_start`, `contract_end`, `is_test_supplier`.

### purchase_order_lines.csv

`po_line_id`, `supplier_id`, `product_id`, `warehouse_region`, `ordered_at`, `promised_at`, `ordered_units`, `unit_cost_native`, `currency`, `status`.

### goods_receipts.csv

`receipt_id`, `po_line_id`, `received_at`, `accepted_units`, `rejected_units`, `status`.

### inventory_movements.csv

`movement_id`, `product_id`, `warehouse_region`, `event_at`, `movement_type`, `units_delta`, `source_id`, `status`.

### stock_policies.csv

`product_id`, `warehouse_region`, `valid_from`, `valid_to`, `reorder_point`, `target_units`.

### return_inspections.csv

`inspection_id`, `refund_id`, `warehouse_region`, `inspected_at`, `units_received`, `restockable_units`, `recovery_unit_value_eur`, `disposition`, `status`.

### support_worklogs.csv

`worklog_id`, `ticket_id`, `worked_at`, `minutes_worked`, `hourly_rate_native`, `currency`, `work_status`, `is_billable`.

### account_contract_versions.csv

`contract_id`, `account_id`, `revision`, `recorded_at`, `valid_from`, `valid_to`, `status`, `service_credit_eur`, `quarterly_fee_eur`, `included_support_minutes`.
