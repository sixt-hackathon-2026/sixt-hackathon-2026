# Project 5: SIXT + TUM

Build an AI-assisted workflow that answers business questions from linked company data.

Inputs: each stage provides 37 CSV tables, 200 questions and explicit business rules.

Task: calculate 150 company metrics and 50 allocation, event-replay or what-if answers per stage. Apply the stated constraints and event order; use the separate final-stage data for the second submission.

Submission: a CSV with question_id and answer, plus your method explanation and presentation. The marking scheme shows the scoring and small-model bonus.

Release: these three toy examples are introductory. Ioannis will release the competition data, questions and full instructions later.

[Six-slide preview](STUDENT_GUIDE.pdf) | [Three solved toy examples](examples/README.md)

![Challenge architecture](assets/challenge_architecture.png)

![Marking scheme](assets/marking_scheme.png)

Contact: Ioannis Tzachristas | ioannis.tzachristas@tum.de | [LinkedIn](https://www.linkedin.com/in/ioannis-tzachristas-83a00522a/)
